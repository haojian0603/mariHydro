# MariHydro 重构改进计划

**基于检查报告**: INSPECTION_REPORT.md  
**制定日期**: 2024-12-10

---

## 一、改进优先级

### P0 - 紧急修复（编译阻塞）
| 序号 | 问题 | 影响 | 预计工时 |
|------|------|------|----------|
| P0.1 | traits.rs 语法错误 | 编译失败 | 0.5h |

### P1 - 高优先级（架构完整性）
| 序号 | 问题 | 影响 | 预计工时 |
|------|------|------|----------|
| P1.1 | 双轨制代码合并 | 维护成本高 | 4h |
| P1.2 | mh_foundation Scalar重导出 | 类型一致性 | 1h |
| P1.3 | 泛型策略完善 | 功能完整性 | 3h |

### P2 - 中优先级（功能完善）
| 序号 | 问题 | 影响 | 预计工时 |
|------|------|------|----------|
| P2.1 | 测试覆盖补全 | 质量保证 | 4h |
| P2.2 | TracerField泛型化 | 一致性 | 2h |
| P2.3 | 统一Solver调度器 | 架构清晰 | 3h |

### P3 - 低优先级（扩展功能）
| 序号 | 问题 | 影响 | 预计工时 |
|------|------|------|----------|
| P3.1 | GPU后端实现 | 性能提升 | 8h+ |
| P3.2 | EnKF同化实现 | 功能扩展 | 4h |
| P3.3 | ONNX集成 | AI能力 | 4h |

---

## 二、详细改进方案

### P0.1 修复 traits.rs 严重语法错误

**问题描述**: `sources/traits.rs` 第270-350行存在多处严重语法错误：

1. `SourceStiffness` 枚举被错误地放在了 `impl SourceHelpers` 块内
2. `SourceContributionGeneric<S>` 结构体定义缺少 `pub struct` 声明
3. `SourceContextGeneric<S>` 结构体定义也缺少完整的声明

**修复方案**:

需要重写第270-400行的代码，正确的结构应该是：

```rust
// ============= 第270行开始修复 =============

/// 源项辅助函数
pub struct SourceHelpers;

impl SourceHelpers {
    /// 安全累加（忽略无效值）
    #[inline]
    pub fn safe_accumulate(acc: &mut f64, val: f64) {
        if val.is_finite() {
            *acc += val;
        }
    }

    /// 验证贡献值并钳位
    #[inline]
    pub fn validate_contribution(val: f64, max_abs: f64) -> f64 {
        if !val.is_finite() {
            return 0.0;
        }
        val.clamp(-max_abs, max_abs)
    }

    /// 光滑过渡函数 (干湿过渡)
    #[inline]
    pub fn smooth_transition(h: f64, h_dry: f64, h_wet: f64) -> f64 {
        if h <= h_dry {
            0.0
        } else if h >= h_wet {
            1.0
        } else {
            (h - h_dry) / (h_wet - h_dry)
        }
    }

    /// 计算安全速度（避免除以零）
    #[inline]
    pub fn safe_velocity(hu: f64, hv: f64, h: f64, h_min: f64) -> (f64, f64) {
        let h_safe = h.max(h_min);
        (hu / h_safe, hv / h_safe)
    }
}

// =============================================================================
// 泛型版本（推荐使用）
// =============================================================================

/// 源项刚性分类
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum SourceStiffness {
    /// 显式处理：源项较为平缓，可以显式积分
    Explicit,
    /// 局部隐式：源项可能较刚性（如摩擦），需要局部隐式处理
    LocallyImplicit,
    /// 全隐式：需要在全局隐式求解器中处理
    FullyImplicit,
}

/// 泛型源项贡献
#[derive(Debug, Clone, Copy)]
pub struct SourceContributionGeneric<S: Scalar> {
    /// 质量源 [m/s]
    pub s_h: S,
    /// x 方向动量源 [m²/s²]
    pub s_hu: S,
    /// y 方向动量源 [m²/s²]
    pub s_hv: S,
}

impl<S: Scalar> Default for SourceContributionGeneric<S> {
    fn default() -> Self {
        Self {
            s_h: S::ZERO,
            s_hu: S::ZERO,
            s_hv: S::ZERO,
        }
    }
}

// ... 其余 impl 块保持不变 ...

/// 泛型源项计算上下文
#[derive(Debug, Clone)]
pub struct SourceContextGeneric<S: Scalar> {
    /// 当前模拟时间 [s]
    pub time: f64,
    /// 时间步长 [s]
    pub dt: S,
    /// 重力加速度 [m/s²]
    pub gravity: S,
    /// 干单元阈值 [m]
    pub h_dry: S,
    /// 湿单元阈值 [m]
    pub h_wet: S,
}

// ... 其余代码 ...
```

**问题根源分析**:

经过详细检查，发现文件中存在以下问题：

1. **第278-287行**: `SourceStiffness` 枚举被错误地写成了 `impl SourceHelpers` 块
2. **第290-298行**: `SourceContributionGeneric<S>` 结构体缺少 `pub struct` 声明
3. **第345-358行**: `SourceContextGeneric<S>` 结构体缺少 `pub struct` 声明
4. **第494-530行**: `SourceHelpers` 的 impl 方法被错误地放在了 deprecated 别名声明之后

**操作步骤**:

**步骤1**: 修复第278-287行（SourceStiffness枚举）

将：
```rust
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
impl SourceHelpers {
    Explicit,
    LocallyImplicit,
    FullyImplicit,
}
```

改为：
```rust
/// 源项刚性分类
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum SourceStiffness {
    /// 显式处理
    Explicit,
    /// 局部隐式
    LocallyImplicit,
    /// 全隐式
    FullyImplicit,
}
```

**步骤2**: 修复第290-298行（SourceContributionGeneric结构体）

将：
```rust
#[derive(Debug, Clone, Copy)]
    /// 安全累加（忽略无效值）
    /// 质量源 [m/s]
    pub s_h: S,
```

改为：
```rust
/// 泛型源项贡献
#[derive(Debug, Clone, Copy)]
pub struct SourceContributionGeneric<S: Scalar> {
    /// 质量源 [m/s]
    pub s_h: S,
```

**步骤3**: 修复第345-358行（SourceContextGeneric结构体）

将：
```rust
#[derive(Debug, Clone)]
    #[inline]
    /// 当前模拟时间 [s]
    pub time: f64,
```

改为：
```rust
/// 泛型源项计算上下文
#[derive(Debug, Clone)]
pub struct SourceContextGeneric<S: Scalar> {
    /// 当前模拟时间 [s]
    pub time: f64,
```

**步骤4**: 修复第494-530行（SourceHelpers impl块）

将：
```rust
#[deprecated(since = "0.4.0", note = "Use SourceTermGeneric<CpuBackend<f64>> instead")]
    pub fn safe_accumulate(acc: &mut f64, val: f64) {
```

改为：
```rust
/// 向后兼容别名
#[deprecated(since = "0.4.0", note = "Use SourceTermGeneric<CpuBackend<f64>> instead")]
pub type SourceTermF64 = dyn SourceTermGeneric<CpuBackend<f64>>;

impl SourceHelpers {
    /// 安全累加（忽略无效值）
    pub fn safe_accumulate(acc: &mut f64, val: f64) {
```

**步骤5**: 验证修复
```bash
cargo check -p mh_physics
cargo test -p mh_physics
```

---

### P1.1 双轨制代码合并

**问题描述**: 状态和源项模块同时存在泛型和非泛型版本，增加维护成本。

**合并策略**:

#### 1. 状态合并 (state.rs)

```rust
// 目标：将 ShallowWaterState 作为 ShallowWaterStateGeneric<CpuBackend<f64>> 的别名

// 步骤1：确保 ShallowWaterStateGeneric 功能完整
impl<B: Backend> ShallowWaterStateGeneric<B> {
    // 迁移 ShallowWaterState 的所有方法
}

// 步骤2：添加类型别名
pub type ShallowWaterState = ShallowWaterStateGeneric<CpuBackend<f64>>;

// 步骤3：标记旧版本废弃（如果需要保留过渡期）
#[deprecated(since = "0.5.0", note = "Use ShallowWaterStateGeneric<CpuBackend<f64>> instead")]
pub struct ShallowWaterStateLegacy { ... }
```

#### 2. 源项合并 (sources/traits.rs)

```rust
// 目标：统一为泛型版本

// 步骤1：将 SourceTerm 改为 SourceTermGeneric 的别名
#[deprecated(since = "0.5.0", note = "Use SourceTermGeneric<CpuBackend<f64>> instead")]
pub type SourceTerm = dyn SourceTermGeneric<CpuBackend<f64>>;

// 步骤2：将 SourceContribution 改为泛型版本的别名
pub type SourceContribution = SourceContributionGeneric<f64>;

// 步骤3：将 SourceContext 改为泛型版本的别名
pub type SourceContext<'a> = SourceContextGeneric<f64>;
```

#### 3. 摩擦源项合并 (sources/friction.rs)

```rust
// 目标：统一为泛型版本

// 步骤1：将 ManningFriction 改为泛型版本的别名
pub type ManningFriction = ManningFrictionGeneric<CpuBackend<f64>>;
pub type ManningFrictionConfig = ManningFrictionConfigGeneric<f64>;

// 步骤2：类似处理 ChezyFriction
pub type ChezyFriction = ChezyFrictionGeneric<CpuBackend<f64>>;
pub type ChezyFrictionConfig = ChezyFrictionConfigGeneric<f64>;
```

**操作步骤**:
1. 备份当前代码
2. 按上述策略修改 `state.rs`
3. 按上述策略修改 `sources/traits.rs`
4. 按上述策略修改 `sources/friction.rs`
5. 更新所有引用点
6. 运行 `cargo check --all` 验证
7. 运行 `cargo test --all` 确保功能正常

---

### P1.2 mh_foundation Scalar 重导出

**问题描述**: `mh_foundation/src/scalar.rs` 仍保留独立的 `Float` trait，未按计划重导出 `mh_physics::core::Scalar`。

**修复方案**:

```rust
// mh_foundation/src/scalar.rs

//! Scalar 类型重导出
//!
//! 权威定义位于 `mh_physics::core::scalar`
//! 此模块仅提供向后兼容重导出

// 注意：由于 mh_foundation 是 mh_physics 的依赖，
// 不能直接重导出 mh_physics 的类型（会造成循环依赖）
// 
// 解决方案：
// 1. 将 Scalar trait 移到 mh_foundation
// 2. 或者保持当前结构，但标记 Float trait 为废弃

/// 浮点数 trait（已废弃，请使用 mh_physics::core::Scalar）
#[deprecated(
    since = "0.5.0",
    note = "Use mh_physics::core::Scalar instead. This trait will be removed in future versions."
)]
pub trait Float: num_traits::Float + Copy + Default + Send + Sync + 'static {
    // ... 保持现有实现
}

// 添加说明文档
//! # 迁移指南
//!
//! 如果您正在使用 `mh_foundation::Float`，请迁移到 `mh_physics::core::Scalar`：
//!
//! ```rust
//! // 旧代码
//! use mh_foundation::Float;
//!
//! // 新代码
//! use mh_physics::core::Scalar;
//! ```
```

**替代方案（推荐）**:

考虑到依赖关系，更好的方案是：
1. 在 `mh_foundation` 中保留基础的 `Float` trait
2. 在 `mh_physics::core::Scalar` 中要求 `Float` 作为 supertrait
3. 这样可以保持向后兼容，同时逐步迁移

```rust
// mh_physics/src/core/scalar.rs
pub trait Scalar: mh_foundation::Float + ... {
    // 扩展方法
}
```

---

### P1.3 泛型策略完善

**问题描述**: `ExplicitStrategy` 和 `SemiImplicitStrategyGeneric` 仅为 `CpuBackend<f64>` 实现。

**修复方案**:

#### 1. 泛型化 ExplicitStrategy

```rust
// engine/strategy/explicit.rs

/// 泛型显式策略
pub struct ExplicitStrategyGeneric<B: Backend> {
    config: ExplicitConfig,
    backend: B,
    // ... 其他字段
}

impl<B: Backend> ExplicitStrategyGeneric<B> {
    pub fn new_with_backend(backend: B, config: ExplicitConfig) -> Self {
        Self { config, backend, ... }
    }
}

// 为所有 Backend 实现 TimeIntegrationStrategy
impl<B: Backend> TimeIntegrationStrategy<B> for ExplicitStrategyGeneric<B>
where
    B::Buffer<B::Scalar>: DeviceBuffer<B::Scalar>,
{
    fn name(&self) -> &'static str { "Explicit-Godunov" }
    
    fn step(
        &mut self,
        state: &mut ShallowWaterStateGeneric<B>,
        mesh: &dyn MeshTopology<B>,
        workspace: &mut SolverWorkspaceGeneric<B>,
        dt: B::Scalar,
    ) -> StepResult<B::Scalar> {
        // 使用 backend 实例方法进行计算
        // ...
    }
    
    fn compute_stable_dt(
        &self,
        state: &ShallowWaterStateGeneric<B>,
        mesh: &dyn MeshTopology<B>,
        cfl: B::Scalar,
    ) -> B::Scalar {
        // ...
    }
}

// 类型别名保持向后兼容
pub type ExplicitStrategy = ExplicitStrategyGeneric<CpuBackend<f64>>;
```

#### 2. 类似处理 SemiImplicitStrategy

```rust
// 将 SemiImplicitStrategyGeneric 的 impl 块改为泛型
impl<B: Backend> TimeIntegrationStrategy<B> for SemiImplicitStrategyGeneric<B>
where
    B::Buffer<B::Scalar>: DeviceBuffer<B::Scalar>,
{
    // ...
}
```

---

### P2.1 测试覆盖补全

**问题描述**: 测试文件存在但内容简单，覆盖不足。

**补全方案**:

#### 1. backend_generic.rs 补全

```rust
// tests/backend_generic.rs

#[test]
fn test_f32_f64_consistency() {
    let backend_f32 = CpuBackend::<f32>::new();
    let backend_f64 = CpuBackend::<f64>::new();
    
    let n = 1000;
    
    // 测试 axpy
    let x_f32 = backend_f32.alloc_init(n, 1.0f32);
    let mut y_f32 = backend_f32.alloc_init(n, 2.0f32);
    backend_f32.axpy(0.5, &x_f32, &mut y_f32);
    
    let x_f64 = backend_f64.alloc_init(n, 1.0f64);
    let mut y_f64 = backend_f64.alloc_init(n, 2.0f64);
    backend_f64.axpy(0.5, &x_f64, &mut y_f64);
    
    // 比较结果
    for i in 0..n {
        let diff = (y_f32[i] as f64 - y_f64[i]).abs();
        assert!(diff < 1e-5, "f32/f64 inconsistency at {}: {}", i, diff);
    }
}

#[test]
fn test_reduce_operations_consistency() {
    // 测试 reduce_max, reduce_min, reduce_sum 的 f32/f64 一致性
}

#[test]
fn test_norm2_precision() {
    // 测试 L2 范数计算精度
}

#[test]
fn test_elementwise_operations() {
    // 测试逐元素操作
}
```

#### 2. strategy_switching.rs 补全

```rust
// tests/strategy_switching.rs

#[test]
fn test_strategy_state_continuity() {
    // 测试策略切换时状态连续性
    // 1. 使用显式策略运行若干步
    // 2. 切换到半隐式策略
    // 3. 验证状态没有跳变
}

#[test]
fn test_explicit_cfl_limit() {
    // 测试显式策略的 CFL 限制
}

#[test]
fn test_semi_implicit_large_cfl() {
    // 测试半隐式策略支持大 CFL
}
```

#### 3. sediment_coupling.rs 补全

```rust
// tests/sediment_coupling.rs

#[test]
fn test_mass_conservation_long_run() {
    // 长时间运行测试质量守恒
    // 运行 1000 步，验证总质量误差 < 1e-10
}

#[test]
fn test_erosion_deposition_equilibrium() {
    // 测试侵蚀-沉降平衡
    // 在 tau = tau_critical 时，净通量应为零
}

#[test]
fn test_negative_mass_prevention() {
    // 测试负质量防护
    // 侵蚀不应超过床面存量
}
```

#### 4. ai_assimilation.rs 补全

```rust
// tests/ai_assimilation.rs

#[test]
fn test_nudging_rate() {
    // 测试 Nudging 同化率
    // 验证修正量与同化率成正比
}

#[test]
fn test_conservation_after_assimilation() {
    // 测试同化后守恒性
}

#[test]
fn test_spatial_smoothing() {
    // 测试空间平滑功能
}
```

---

### P2.2 TracerField 泛型化

**问题描述**: `tracer/state.rs` 中的 `TracerField` 仍使用 `Vec<f64>`。

**修复方案**:

```rust
// tracer/state.rs

/// 泛型示踪剂场
pub struct TracerFieldGeneric<B: Backend> {
    /// 物理属性
    pub properties: TracerProperties,
    /// 浓度场 [单位/m³]
    concentration: B::Buffer<B::Scalar>,
    /// 守恒量 h*C
    conserved: B::Buffer<B::Scalar>,
    /// RHS
    rhs: B::Buffer<B::Scalar>,
    /// 单元数量
    n_cells: usize,
}

impl<B: Backend> TracerFieldGeneric<B> {
    pub fn new_with_backend(
        backend: &B,
        n_cells: usize,
        properties: TracerProperties,
    ) -> Self {
        Self {
            properties,
            concentration: backend.alloc(n_cells),
            conserved: backend.alloc(n_cells),
            rhs: backend.alloc(n_cells),
            n_cells,
        }
    }
    
    pub fn concentration(&self) -> &B::Buffer<B::Scalar> {
        &self.concentration
    }
    
    pub fn concentration_mut(&mut self) -> &mut B::Buffer<B::Scalar> {
        &mut self.concentration
    }
}

// 类型别名
pub type TracerField = TracerFieldGeneric<CpuBackend<f64>>;
```

---

### P2.3 统一 Solver 调度器

**问题描述**: `engine/solver.rs` 未按计划重构为纯调度器。

**修复方案**:

```rust
// engine/solver.rs

/// 浅水方程求解器（调度器）
pub struct ShallowWaterSolver<B: Backend> {
    /// 网格
    mesh: Arc<dyn MeshTopology<B>>,
    /// 状态
    state: ShallowWaterStateGeneric<B>,
    /// 时间积分策略
    strategy: Box<dyn TimeIntegrationStrategy<B>>,
    /// 工作区
    workspace: SolverWorkspaceGeneric<B>,
    /// 源项注册
    sources: SourceRegistry<B>,
    /// 边界管理
    boundary: BoundaryManager<B>,
    /// 当前时间
    current_time: f64,
    /// 配置
    config: SolverConfig,
}

impl<B: Backend> ShallowWaterSolver<B> {
    /// 执行单步
    pub fn step(&mut self, dt: B::Scalar) -> StepResult<B::Scalar> {
        // 1. 边界条件准备
        self.boundary.apply(&mut self.state);
        
        // 2. 委托策略执行
        let result = self.strategy.step(
            &mut self.state,
            self.mesh.as_ref(),
            &mut self.workspace,
            dt,
        );
        
        // 3. 更新时间
        self.current_time += dt.to_f64();
        
        result
    }
    
    /// 运行时切换策略
    pub fn set_strategy(&mut self, strategy: Box<dyn TimeIntegrationStrategy<B>>) {
        self.strategy = strategy;
    }
    
    /// 获取状态引用
    pub fn state(&self) -> &ShallowWaterStateGeneric<B> {
        &self.state
    }
    
    /// 获取状态可变引用
    pub fn state_mut(&mut self) -> &mut ShallowWaterStateGeneric<B> {
        &mut self.state
    }
}
```

---

## 三、执行计划

### 第一阶段：紧急修复（Day 1）（已经完成✅）

1. **P0.1**: 修复 traits.rs 语法错误
   - 修改文件
   - 验证编译
   - 提交代码

### 第二阶段：架构完整性（Day 2-3）

1. **P1.1**: 双轨制代码合并
   - 合并状态类型
   - 合并源项类型
   - 更新引用
   - 验证测试

2. **P1.2**: mh_foundation Scalar 处理
   - 添加废弃标记（废弃后直接删除）
   - 更新文档

3. **P1.3**: 泛型策略完善
   - 泛型化 ExplicitStrategy
   - 泛型化 SemiImplicitStrategy
   - 验证测试

### 第三阶段：功能完善（Day 4-5）

1. **P2.1**: 测试覆盖补全或完善
   - 补全完善 backend_generic.rs
   - 补全完善 strategy_switching.rs
   - 补全完善 sediment_coupling.rs
   - 补全完善 ai_assimilation.rs

2. **P2.2**: TracerField 泛型化
   - 创建泛型版本
   - 添加类型别名
   - 更新引用

3. **P2.3**: 统一 Solver 调度器
   - 重构 solver.rs
   - 实现策略切换
   - 验证测试

### 第四阶段：扩展功能（后续）

1. **P3.1**: GPU 后端实现（需要 CUDA 环境）
2. **P3.2**: EnKF 同化实现
3. **P3.3**: ONNX 集成

---

## 四、验证检查点

### 检查点 1：编译通过
```bash
cargo check --all
```

### 检查点 2：测试通过
```bash
cargo test --all
```

### 检查点 3：无警告
```bash
cargo clippy --all -- -D warnings
```

### 检查点 4：文档生成
```bash
cargo doc --no-deps
```

---

## 五、风险缓解

### 风险 1：合并导致功能回归
- **缓解**: 在合并前确保所有现有测试通过
- **缓解**: 保留类型别名确保向后兼容

### 风险 2：泛型化导致编译时间增加
- **缓解**: 使用 type alias 减少泛型传播深度
- **缓解**: 考虑使用 `#[inline]` 优化热点代码

### 风险 3：GPU 后端实现复杂
- **缓解**: 先完成 CPU 泛型化，GPU 作为后续阶段
- **缓解**: 使用 feature gate 隔离 GPU 代码

---

## 六、成功标准

1. ✅ 所有代码编译通过，无错误
2. ✅ 所有测试通过
3. ✅ 无 clippy 警告
4. ✅ 双轨制代码合并完成
5. ✅ 泛型策略可用于 f32/f64
6. ✅ 测试覆盖率 > 70%


---

## 七、快速修复脚本

为了快速修复 P0.1 问题，可以使用以下步骤：

### 7.1 手动修复要点

由于 traits.rs 文件的问题比较复杂，建议按以下顺序手动修复：

1. **备份原文件**
2. **定位并修复每个问题点**
3. **逐步验证编译**

### 7.2 修复后的预期结构

```
traits.rs 文件结构（修复后）:
├── 非泛型版本（向后兼容）
│   ├── SourceContribution
│   ├── SourceContext
│   └── SourceTerm trait
├── SourceHelpers struct + impl
├── 泛型版本（推荐）
│   ├── SourceStiffness enum
│   ├── SourceContributionGeneric<S>
│   ├── SourceContextGeneric<S>
│   ├── SourceTermGeneric<B> trait
│   └── SourceRegistryGeneric<B>
├── 类型别名（废弃标记）
└── 测试模块
```

---

## 八、后续跟踪

### 8.1 修复验证清单

- [ ] P0.1: traits.rs 语法错误修复
- [ ] P1.1: 双轨制代码合并
- [ ] P1.2: mh_foundation Scalar 处理
- [ ] P1.3: 泛型策略完善
- [ ] P2.1: 测试覆盖补全
- [ ] P2.2: TracerField 泛型化
- [ ] P2.3: 统一 Solver 调度器

### 8.2 里程碑

| 里程碑 | 目标日期 | 验收标准 |
|--------|----------|----------|
| M1: 编译通过 | Day 1 | `cargo check --all` 成功 |
| M2: 测试通过 | Day 3 | `cargo test --all` 成功 |
| M3: 架构完整 | Day 5 | 双轨制合并完成 |
| M4: 质量达标 | Day 7 | clippy 无警告 |

---

**文档版本**: 1.0  
**创建日期**: 2024-12-10  
**作者**: Kiro AI Assistant  
**基于**: INSPECTION_REPORT.md 检查结果
