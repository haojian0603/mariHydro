# Phase 2: 网格与状态泛型化

## 概述

**时间**: 第4-5周  
**目标**: 建立 MeshTopology 抽象，完成 State 泛型化

## 前置依赖

- Phase 0-1 完成
- `core/backend.rs` 中的 Backend trait 可用
- `core/buffer.rs` 中的 DeviceBuffer trait 可用

---

## 任务 2.1: 创建 mesh 模块结构

**新建文件**:
- `mh_physics/src/mesh/mod.rs`
- `mh_physics/src/mesh/topology.rs`
- `mh_physics/src/mesh/unstructured.rs`
- `mh_physics/src/mesh/structured.rs`

**改动文件**:
- `mh_physics/src/lib.rs` → 添加 `pub mod mesh;`

---

## 任务 2.2: 实现 MeshTopology trait

**文件**: `mh_physics/src/mesh/topology.rs`

```rust
//! 网格拓扑抽象
//!
//! 提供结构化和非结构化网格的统一接口。

use crate::core::{Backend, Scalar};

/// 网格类型
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum MeshKind {
    /// 非结构化网格
    Unstructured,
    /// 结构化网格
    Structured { nx: usize, ny: usize },
}

/// 面信息
#[derive(Debug, Clone, Copy)]
pub struct FaceInfo<S: Scalar> {
    /// 面法向量 (指向 neighbor)
    pub normal: [S; 2],
    /// 面长度
    pub length: S,
    /// 面中心坐标
    pub center: [S; 2],
    /// 所属单元 (owner)
    pub owner: usize,
    /// 相邻单元 (neighbor)，边界面为 None
    pub neighbor: Option<usize>,
}

/// 网格拓扑 trait
pub trait MeshTopology<B: Backend>: Send + Sync {
    // ========== 基本信息 ==========
    
    /// 单元数量
    fn n_cells(&self) -> usize;
    
    /// 面数量
    fn n_faces(&self) -> usize;
    
    /// 内部面数量
    fn n_interior_faces(&self) -> usize;
    
    /// 边界面数量
    fn n_boundary_faces(&self) -> usize {
        self.n_faces() - self.n_interior_faces()
    }
    
    /// 节点数量
    fn n_nodes(&self) -> usize;
    
    // ========== 几何数据 ==========
    
    /// 单元中心坐标
    fn cell_center(&self, cell: usize) -> [B::Scalar; 2];
    
    /// 单元面积
    fn cell_area(&self, cell: usize) -> B::Scalar;
    
    /// 面法向量
    fn face_normal(&self, face: usize) -> [B::Scalar; 2];
    
    /// 面长度
    fn face_length(&self, face: usize) -> B::Scalar;
    
    /// 面中心坐标
    fn face_center(&self, face: usize) -> [B::Scalar; 2];
    
    // ========== 拓扑数据 ==========
    
    /// 面的 owner 单元
    fn face_owner(&self, face: usize) -> usize;
    
    /// 面的 neighbor 单元（边界面返回 None）
    fn face_neighbor(&self, face: usize) -> Option<usize>;
    
    /// 单元的所有面索引
    fn cell_faces(&self, cell: usize) -> &[usize];
    
    /// 单元的相邻单元索引
    fn cell_neighbors(&self, cell: usize) -> Vec<usize>;
    
    // ========== 边界信息 ==========
    
    /// 是否为边界面
    fn is_boundary_face(&self, face: usize) -> bool {
        self.face_neighbor(face).is_none()
    }
    
    /// 边界面索引列表
    fn boundary_faces(&self) -> &[usize];
    
    /// 内部面索引列表
    fn interior_faces(&self) -> &[usize];
    
    // ========== 网格类型 ==========
    
    /// 网格类型
    fn mesh_kind(&self) -> MeshKind;
    
    // ========== 批量访问（GPU 优化入口）==========
    
    /// 获取所有单元面积（设备缓冲区）
    fn cell_areas_buffer(&self) -> &B::Buffer<B::Scalar>;
    
    /// 获取所有面长度（设备缓冲区）
    fn face_lengths_buffer(&self) -> &B::Buffer<B::Scalar>;
}

/// 网格几何计算辅助函数
pub struct MeshGeometry;

impl MeshGeometry {
    /// 计算两点间距离
    #[inline]
    pub fn distance<S: Scalar>(p1: [S; 2], p2: [S; 2]) -> S {
        let dx = p2[0] - p1[0];
        let dy = p2[1] - p1[1];
        (dx * dx + dy * dy).sqrt()
    }
    
    /// 计算单位法向量
    #[inline]
    pub fn unit_normal<S: Scalar>(p1: [S; 2], p2: [S; 2]) -> [S; 2] {
        let dx = p2[0] - p1[0];
        let dy = p2[1] - p1[1];
        let len = (dx * dx + dy * dy).sqrt();
        if len > S::epsilon() {
            [-dy / len, dx / len]
        } else {
            [S::from_f64(0.0), S::from_f64(0.0)]
        }
    }
}
```

---

## 任务 2.3: 实现 FrozenMesh 适配器

**文件**: `mh_physics/src/mesh/unstructured.rs`

```rust
//! 非结构化网格适配器
//!
//! 将现有的 FrozenMesh/PhysicsMesh 适配到 MeshTopology trait。

use crate::adapter::PhysicsMesh;
use crate::core::{Backend, CpuBackend, Scalar};
use super::topology::{MeshKind, MeshTopology};
use std::sync::Arc;

/// 非结构化网格适配器
pub struct UnstructuredMeshAdapter<B: Backend = CpuBackend<f64>> {
    /// 原始网格引用
    mesh: Arc<PhysicsMesh>,
    /// 单元面积缓冲区
    cell_areas: B::Buffer<B::Scalar>,
    /// 面长度缓冲区
    face_lengths: B::Buffer<B::Scalar>,
    /// 边界面索引
    boundary_face_indices: Vec<usize>,
    /// 内部面索引
    interior_face_indices: Vec<usize>,
    /// 单元-面映射缓存
    cell_face_map: Vec<Vec<usize>>,
}

impl<B: Backend> UnstructuredMeshAdapter<B> {
    /// 从 PhysicsMesh 创建适配器
    pub fn from_physics_mesh(mesh: Arc<PhysicsMesh>) -> Self {
        let n_cells = mesh.n_cells();
        let n_faces = mesh.n_faces();
        
        // 构建单元面积缓冲区
        let areas: Vec<B::Scalar> = (0..n_cells)
            .map(|i| B::Scalar::from_f64(mesh.cell_area(i).unwrap_or(0.0)))
            .collect();
        let cell_areas = B::alloc_init(n_cells, B::Scalar::from_f64(0.0));
        
        // 构建面长度缓冲区
        let lengths: Vec<B::Scalar> = (0..n_faces)
            .map(|i| B::Scalar::from_f64(mesh.face_length(i)))
            .collect();
        let face_lengths = B::alloc_init(n_faces, B::Scalar::from_f64(0.0));
        
        // 分类边界面和内部面
        let mut boundary_face_indices = Vec::new();
        let mut interior_face_indices = Vec::new();
        for i in 0..n_faces {
            if mesh.face_neighbor(i).is_some() {
                interior_face_indices.push(i);
            } else {
                boundary_face_indices.push(i);
            }
        }
        
        // 构建单元-面映射
        let mut cell_face_map = vec![Vec::new(); n_cells];
        for face_idx in 0..n_faces {
            let owner = mesh.face_owner(face_idx);
            cell_face_map[owner].push(face_idx);
            if let Some(neighbor) = mesh.face_neighbor(face_idx) {
                cell_face_map[neighbor].push(face_idx);
            }
        }
        
        Self {
            mesh,
            cell_areas: {
                let mut buf = B::alloc::<B::Scalar>(n_cells);
                if let Some(slice) = buf.as_slice_mut() {
                    slice.copy_from_slice(&areas.iter().map(|&x| x).collect::<Vec<_>>());
                }
                buf
            },
            face_lengths: {
                let mut buf = B::alloc::<B::Scalar>(n_faces);
                if let Some(slice) = buf.as_slice_mut() {
                    slice.copy_from_slice(&lengths.iter().map(|&x| x).collect::<Vec<_>>());
                }
                buf
            },
            boundary_face_indices,
            interior_face_indices,
            cell_face_map,
        }
    }
    
    /// 获取原始网格引用
    pub fn inner(&self) -> &PhysicsMesh {
        &self.mesh
    }
}

impl<B: Backend> MeshTopology<B> for UnstructuredMeshAdapter<B> {
    fn n_cells(&self) -> usize {
        self.mesh.n_cells()
    }
    
    fn n_faces(&self) -> usize {
        self.mesh.n_faces()
    }
    
    fn n_interior_faces(&self) -> usize {
        self.interior_face_indices.len()
    }
    
    fn n_nodes(&self) -> usize {
        self.mesh.n_nodes()
    }
    
    fn cell_center(&self, cell: usize) -> [B::Scalar; 2] {
        let c = self.mesh.cell_center(cell);
        [B::Scalar::from_f64(c.x), B::Scalar::from_f64(c.y)]
    }
    
    fn cell_area(&self, cell: usize) -> B::Scalar {
        B::Scalar::from_f64(self.mesh.cell_area(cell).unwrap_or(0.0))
    }
    
    fn face_normal(&self, face: usize) -> [B::Scalar; 2] {
        let n = self.mesh.face_normal(face);
        [B::Scalar::from_f64(n.x), B::Scalar::from_f64(n.y)]
    }
    
    fn face_length(&self, face: usize) -> B::Scalar {
        B::Scalar::from_f64(self.mesh.face_length(face))
    }
    
    fn face_center(&self, face: usize) -> [B::Scalar; 2] {
        let c = self.mesh.face_center(face);
        [B::Scalar::from_f64(c.x), B::Scalar::from_f64(c.y)]
    }
    
    fn face_owner(&self, face: usize) -> usize {
        self.mesh.face_owner(face)
    }
    
    fn face_neighbor(&self, face: usize) -> Option<usize> {
        self.mesh.face_neighbor(face)
    }
    
    fn cell_faces(&self, cell: usize) -> &[usize] {
        &self.cell_face_map[cell]
    }
    
    fn cell_neighbors(&self, cell: usize) -> Vec<usize> {
        self.cell_face_map[cell]
            .iter()
            .filter_map(|&face| {
                let owner = self.mesh.face_owner(face);
                let neighbor = self.mesh.face_neighbor(face);
                if owner == cell {
                    neighbor
                } else {
                    Some(owner)
                }
            })
            .collect()
    }
    
    fn boundary_faces(&self) -> &[usize] {
        &self.boundary_face_indices
    }
    
    fn interior_faces(&self) -> &[usize] {
        &self.interior_face_indices
    }
    
    fn mesh_kind(&self) -> MeshKind {
        MeshKind::Unstructured
    }
    
    fn cell_areas_buffer(&self) -> &B::Buffer<B::Scalar> {
        &self.cell_areas
    }
    
    fn face_lengths_buffer(&self) -> &B::Buffer<B::Scalar> {
        &self.face_lengths
    }
}
```

---

## 任务 2.4: 创建 StructuredMesh 骨架

**文件**: `mh_physics/src/mesh/structured.rs`

```rust
//! 结构化网格（骨架实现）
//!
//! 预留结构化网格支持，当前仅提供 trait 实现骨架。

use crate::core::{Backend, Scalar};
use super::topology::{MeshKind, MeshTopology};

/// 结构化网格（未实现）
pub struct StructuredMesh<B: Backend> {
    nx: usize,
    ny: usize,
    dx: B::Scalar,
    dy: B::Scalar,
    _marker: std::marker::PhantomData<B>,
}

impl<B: Backend> StructuredMesh<B> {
    /// 创建结构化网格（未实现）
    pub fn new(_nx: usize, _ny: usize, _dx: f64, _dy: f64) -> Self {
        unimplemented!("StructuredMesh is not yet implemented")
    }
}

impl<B: Backend> MeshTopology<B> for StructuredMesh<B> {
    fn n_cells(&self) -> usize {
        self.nx * self.ny
    }
    
    fn n_faces(&self) -> usize {
        // 内部面 + 边界面
        (self.nx - 1) * self.ny + self.nx * (self.ny - 1) + 2 * (self.nx + self.ny)
    }
    
    fn n_interior_faces(&self) -> usize {
        (self.nx - 1) * self.ny + self.nx * (self.ny - 1)
    }
    
    fn n_nodes(&self) -> usize {
        (self.nx + 1) * (self.ny + 1)
    }
    
    fn cell_center(&self, _cell: usize) -> [B::Scalar; 2] {
        unimplemented!()
    }
    
    fn cell_area(&self, _cell: usize) -> B::Scalar {
        self.dx * self.dy
    }
    
    fn face_normal(&self, _face: usize) -> [B::Scalar; 2] {
        unimplemented!()
    }
    
    fn face_length(&self, _face: usize) -> B::Scalar {
        unimplemented!()
    }
    
    fn face_center(&self, _face: usize) -> [B::Scalar; 2] {
        unimplemented!()
    }
    
    fn face_owner(&self, _face: usize) -> usize {
        unimplemented!()
    }
    
    fn face_neighbor(&self, _face: usize) -> Option<usize> {
        unimplemented!()
    }
    
    fn cell_faces(&self, _cell: usize) -> &[usize] {
        unimplemented!()
    }
    
    fn cell_neighbors(&self, _cell: usize) -> Vec<usize> {
        unimplemented!()
    }
    
    fn boundary_faces(&self) -> &[usize] {
        unimplemented!()
    }
    
    fn interior_faces(&self) -> &[usize] {
        unimplemented!()
    }
    
    fn mesh_kind(&self) -> MeshKind {
        MeshKind::Structured { nx: self.nx, ny: self.ny }
    }
    
    fn cell_areas_buffer(&self) -> &B::Buffer<B::Scalar> {
        unimplemented!()
    }
    
    fn face_lengths_buffer(&self) -> &B::Buffer<B::Scalar> {
        unimplemented!()
    }
}
```

---

## 任务 2.5: 创建 mesh/mod.rs

**文件**: `mh_physics/src/mesh/mod.rs`

```rust
//! 网格抽象层
//!
//! 提供结构化和非结构化网格的统一接口。

pub mod topology;
pub mod unstructured;
pub mod structured;

pub use topology::{MeshKind, MeshTopology, FaceInfo, MeshGeometry};
pub use unstructured::UnstructuredMeshAdapter;
pub use structured::StructuredMesh;
```

---

## 任务 2.6: 泛型化 ShallowWaterState

**改动文件**: `mh_physics/src/state.rs`

### 2.6.1 添加泛型版本

在现有 `ShallowWaterState` 基础上，添加泛型版本：

```rust
use crate::core::{Backend, CpuBackend, DeviceBuffer, Scalar};

/// 泛型浅水状态（新版本）
#[derive(Debug, Clone)]
pub struct ShallowWaterStateGeneric<B: Backend> {
    /// 单元数量
    n_cells: usize,
    /// 水深 [m]
    pub h: B::Buffer<B::Scalar>,
    /// x 方向动量 [m²/s]
    pub hu: B::Buffer<B::Scalar>,
    /// y 方向动量 [m²/s]
    pub hv: B::Buffer<B::Scalar>,
    /// 底床高程 [m]
    pub z: B::Buffer<B::Scalar>,
}

impl<B: Backend> ShallowWaterStateGeneric<B> {
    /// 创建新状态
    pub fn new(n_cells: usize) -> Self {
        Self {
            n_cells,
            h: B::alloc(n_cells),
            hu: B::alloc(n_cells),
            hv: B::alloc(n_cells),
            z: B::alloc(n_cells),
        }
    }
    
    /// 单元数量
    #[inline]
    pub fn n_cells(&self) -> usize {
        self.n_cells
    }
    
    /// 从现有状态转换（仅 CPU 后端）
    pub fn from_legacy(state: &ShallowWaterState) -> Self 
    where
        B: Backend<Scalar = f64, Buffer<f64> = Vec<f64>>,
    {
        let n = state.n_cells();
        let mut new_state = Self::new(n);
        
        if let Some(h) = new_state.h.as_slice_mut() {
            h.copy_from_slice(state.h_slice());
        }
        if let Some(hu) = new_state.hu.as_slice_mut() {
            hu.copy_from_slice(state.hu_slice());
        }
        if let Some(hv) = new_state.hv.as_slice_mut() {
            hv.copy_from_slice(state.hv_slice());
        }
        if let Some(z) = new_state.z.as_slice_mut() {
            z.copy_from_slice(state.z_slice());
        }
        
        new_state
    }
    
    /// 重置为零
    pub fn reset(&mut self) {
        self.h.fill(B::Scalar::from_f64(0.0));
        self.hu.fill(B::Scalar::from_f64(0.0));
        self.hv.fill(B::Scalar::from_f64(0.0));
    }
    
    /// 验证状态有效性
    pub fn is_valid(&self) -> bool {
        if let Some(h) = self.h.as_slice() {
            h.iter().all(|&x| x.is_finite() && x >= B::Scalar::from_f64(0.0))
        } else {
            true // GPU 缓冲区暂不验证
        }
    }
}

/// 类型别名：默认后端的状态
pub type ShallowWaterStateDefault = ShallowWaterStateGeneric<CpuBackend<f64>>;
```

### 2.6.2 保持向后兼容

保留原有 `ShallowWaterState` 不变，添加转换方法：

```rust
impl ShallowWaterState {
    /// 转换为泛型版本
    pub fn to_generic<B: Backend>(&self) -> ShallowWaterStateGeneric<B>
    where
        B::Scalar: From<f64>,
    {
        // 实现转换逻辑
        todo!()
    }
}
```

---

## 任务 2.7: 泛型化 VerticalState

**改动文件**: `mh_physics/src/vertical/state.rs`

```rust
use crate::core::{Backend, DeviceBuffer, Scalar};

/// 泛型垂向状态
#[derive(Debug, Clone)]
pub struct VerticalStateGeneric<B: Backend> {
    /// 单元数量
    n_cells: usize,
    /// 层数
    n_layers: usize,
    /// 各层 u 速度 [n_cells, n_layers]
    pub u_layers: B::Buffer<B::Scalar>,
    /// 各层 v 速度 [n_cells, n_layers]
    pub v_layers: B::Buffer<B::Scalar>,
    /// 各层厚度 [n_cells, n_layers]
    pub layer_thickness: B::Buffer<B::Scalar>,
}

impl<B: Backend> VerticalStateGeneric<B> {
    /// 创建新的垂向状态
    pub fn new(n_cells: usize, n_layers: usize) -> Self {
        let total = n_cells * n_layers;
        Self {
            n_cells,
            n_layers,
            u_layers: B::alloc(total),
            v_layers: B::alloc(total),
            layer_thickness: B::alloc(total),
        }
    }
    
    /// 单元数量
    #[inline]
    pub fn n_cells(&self) -> usize {
        self.n_cells
    }
    
    /// 层数
    #[inline]
    pub fn n_layers(&self) -> usize {
        self.n_layers
    }
    
    /// 获取指定单元和层的索引
    #[inline]
    pub fn index(&self, cell: usize, layer: usize) -> usize {
        cell * self.n_layers + layer
    }
}
```

---

## 任务 2.8: 更新 lib.rs 导出

**改动文件**: `mh_physics/src/lib.rs`

```rust
// 添加 mesh 模块
pub mod mesh;

// 重导出
pub use mesh::{MeshTopology, MeshKind, UnstructuredMeshAdapter};
pub use state::{ShallowWaterStateGeneric, ShallowWaterStateDefault};
```

---

## 验证清单

- [ ] `cargo check -p mh_physics` 通过
- [ ] `cargo test -p mh_physics` 通过
- [ ] MeshTopology trait 可用
- [ ] UnstructuredMeshAdapter 可从 PhysicsMesh 创建
- [ ] ShallowWaterStateGeneric 可实例化
- [ ] 现有测试仍然通过（向后兼容）

```bash
cd marihydro
cargo check -p mh_physics
cargo test -p mh_physics
cargo test -p mh_physics mesh::
cargo test -p mh_physics state::
```

---

## 依赖关系

```
Phase 1 (Backend/Buffer)
    │
    ▼
Phase 2
    │
    ├── mesh/topology.rs (依赖 Backend)
    │
    ├── mesh/unstructured.rs (依赖 topology, PhysicsMesh)
    │
    ├── mesh/structured.rs (依赖 topology)
    │
    └── state.rs 泛型化 (依赖 Backend, Buffer)
```

---

## 时间估计

| 任务 | 预计时间 |
|------|----------|
| 任务 2.1-2.2 | 3 小时 |
| 任务 2.3 | 4 小时 |
| 任务 2.4-2.5 | 2 小时 |
| 任务 2.6 | 4 小时 |
| 任务 2.7-2.8 | 2 小时 |
| 测试与验证 | 3 小时 |
| **总计** | **~18 小时** |
