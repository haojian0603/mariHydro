# Phase 3: 求解器策略化

## 概述

**时间**: 第6-8周  
**目标**: 实现策略模式，统一显式和半隐式求解器

## 前置依赖

- Phase 0-2 完成
- `core/backend.rs` 中的 Backend trait 可用
- `mesh/topology.rs` 中的 MeshTopology trait 可用
- `state.rs` 中的泛型状态可用

---

## 核心设计

### 策略模式架构

```
┌──────────────────────────────────────┐
│       ShallowWaterSolver<B>          │
│  ┌────────────────────────────────┐  │
│  │  TimeIntegrationStrategy<B>    │  │
│  │  ├─ ExplicitStrategy           │  │
│  │  └─ SemiImplicitStrategy       │  │
│  └────────────────────────────────┘  │
│  + 共享: Mesh, Boundary, Sources,    │
│          Workspace                   │
└──────────────────────────────────────┘
```

---

## 任务 3.1: 创建 engine/workspace.rs

**新建文件**: `mh_physics/src/engine/workspace.rs`

```rust
//! 求解器工作区
//!
//! 提供通量、残差、临时变量的统一管理。

use crate::core::{Backend, DeviceBuffer, Scalar};

/// 泛型求解器工作区
#[derive(Debug)]
pub struct SolverWorkspaceGeneric<B: Backend> {
    /// 单元数量
    n_cells: usize,
    /// 面数量
    n_faces: usize,
    
    // ========== 通量累加 ==========
    /// 质量通量累加
    pub flux_h: B::Buffer<B::Scalar>,
    /// x动量通量累加
    pub flux_hu: B::Buffer<B::Scalar>,
    /// y动量通量累加
    pub flux_hv: B::Buffer<B::Scalar>,
    
    // ========== 源项累加 ==========
    /// x动量源项
    pub source_hu: B::Buffer<B::Scalar>,
    /// y动量源项
    pub source_hv: B::Buffer<B::Scalar>,
    
    // ========== 重构辅助 ==========
    /// 单元速度 u
    pub vel_u: B::Buffer<B::Scalar>,
    /// 单元速度 v
    pub vel_v: B::Buffer<B::Scalar>,
    /// 水位 η = h + z
    pub eta: B::Buffer<B::Scalar>,
    
    // ========== 面通量（并行计算用）==========
    /// 面质量通量
    pub face_flux_h: B::Buffer<B::Scalar>,
    /// 面x动量通量
    pub face_flux_hu: B::Buffer<B::Scalar>,
    /// 面y动量通量
    pub face_flux_hv: B::Buffer<B::Scalar>,
    /// 面最大波速
    pub face_wave_speed: B::Buffer<B::Scalar>,
}

impl<B: Backend> SolverWorkspaceGeneric<B> {
    /// 创建工作区
    pub fn new(n_cells: usize, n_faces: usize) -> Self {
        Self {
            n_cells,
            n_faces,
            flux_h: B::alloc(n_cells),
            flux_hu: B::alloc(n_cells),
            flux_hv: B::alloc(n_cells),
            source_hu: B::alloc(n_cells),
            source_hv: B::alloc(n_cells),
            vel_u: B::alloc(n_cells),
            vel_v: B::alloc(n_cells),
            eta: B::alloc(n_cells),
            face_flux_h: B::alloc(n_faces),
            face_flux_hu: B::alloc(n_faces),
            face_flux_hv: B::alloc(n_faces),
            face_wave_speed: B::alloc(n_faces),
        }
    }
    
    /// 重置通量
    pub fn reset_fluxes(&mut self) {
        let zero = B::Scalar::from_f64(0.0);
        self.flux_h.fill(zero);
        self.flux_hu.fill(zero);
        self.flux_hv.fill(zero);
    }
    
    /// 重置源项
    pub fn reset_sources(&mut self) {
        let zero = B::Scalar::from_f64(0.0);
        self.source_hu.fill(zero);
        self.source_hv.fill(zero);
    }
    
    /// 重置所有
    pub fn reset(&mut self) {
        self.reset_fluxes();
        self.reset_sources();
    }
    
    /// 调整大小
    pub fn resize(&mut self, n_cells: usize, n_faces: usize) {
        if self.n_cells != n_cells {
            self.n_cells = n_cells;
            self.flux_h = B::alloc(n_cells);
            self.flux_hu = B::alloc(n_cells);
            self.flux_hv = B::alloc(n_cells);
            self.source_hu = B::alloc(n_cells);
            self.source_hv = B::alloc(n_cells);
            self.vel_u = B::alloc(n_cells);
            self.vel_v = B::alloc(n_cells);
            self.eta = B::alloc(n_cells);
        }
        if self.n_faces != n_faces {
            self.n_faces = n_faces;
            self.face_flux_h = B::alloc(n_faces);
            self.face_flux_hu = B::alloc(n_faces);
            self.face_flux_hv = B::alloc(n_faces);
            self.face_wave_speed = B::alloc(n_faces);
        }
    }
}
```

---

## 任务 3.2: 创建 TimeIntegrationStrategy trait

**新建文件**: `mh_physics/src/engine/strategy/mod.rs`

```rust
//! 时间积分策略
//!
//! 提供显式和半隐式时间积分的统一接口。

pub mod explicit;
pub mod semi_implicit;

use crate::core::{Backend, Scalar};
use crate::mesh::MeshTopology;
use crate::state::ShallowWaterStateGeneric;
use crate::sources::SourceRegistry;
use super::workspace::SolverWorkspaceGeneric;

/// 时间积分步进结果
#[derive(Debug, Clone)]
pub struct StepResult<S: Scalar> {
    /// 使用的时间步长
    pub dt_used: S,
    /// 最大波速
    pub max_wave_speed: S,
    /// 干单元数量
    pub dry_cells: usize,
    /// 被限制的单元数量
    pub limited_cells: usize,
    /// 是否收敛（半隐式）
    pub converged: bool,
    /// 迭代次数（半隐式）
    pub iterations: usize,
}

impl<S: Scalar> Default for StepResult<S> {
    fn default() -> Self {
        Self {
            dt_used: S::from_f64(0.0),
            max_wave_speed: S::from_f64(0.0),
            dry_cells: 0,
            limited_cells: 0,
            converged: true,
            iterations: 0,
        }
    }
}

/// 时间积分策略 trait
pub trait TimeIntegrationStrategy<B: Backend>: Send + Sync {
    /// 策略名称
    fn name(&self) -> &'static str;
    
    /// 执行单步时间积分
    fn step(
        &mut self,
        state: &mut ShallowWaterStateGeneric<B>,
        mesh: &dyn MeshTopology<B>,
        sources: &SourceRegistry<B>,
        workspace: &mut SolverWorkspaceGeneric<B>,
        dt: B::Scalar,
    ) -> StepResult<B::Scalar>;
    
    /// 计算稳定时间步长
    fn compute_stable_dt(
        &self,
        state: &ShallowWaterStateGeneric<B>,
        mesh: &dyn MeshTopology<B>,
        cfl: B::Scalar,
    ) -> B::Scalar;
    
    /// 是否支持大 CFL 数
    fn supports_large_cfl(&self) -> bool {
        false
    }
    
    /// 推荐的 CFL 数
    fn recommended_cfl(&self) -> B::Scalar {
        B::Scalar::from_f64(0.5)
    }
}

/// 策略类型枚举
#[derive(Debug, Clone)]
pub enum StrategyKind {
    /// 显式 Godunov
    Explicit(ExplicitConfig),
    /// 半隐式压力校正
    SemiImplicit(SemiImplicitConfig),
}

/// 显式策略配置
#[derive(Debug, Clone, Default)]
pub struct ExplicitConfig {
    /// CFL 数
    pub cfl: f64,
    /// 是否使用二阶重构
    pub second_order: bool,
    /// 是否使用静水重构
    pub hydrostatic_reconstruction: bool,
}

/// 半隐式策略配置
#[derive(Debug, Clone)]
pub struct SemiImplicitConfig {
    /// 重力加速度
    pub gravity: f64,
    /// 最小水深
    pub h_min: f64,
    /// 求解器容差
    pub solver_rtol: f64,
    /// 最大迭代次数
    pub solver_max_iter: usize,
    /// 隐式因子 (0=显式, 1=全隐式)
    pub theta: f64,
}

impl Default for SemiImplicitConfig {
    fn default() -> Self {
        Self {
            gravity: 9.81,
            h_min: 1e-6,
            solver_rtol: 1e-8,
            solver_max_iter: 200,
            theta: 0.5,
        }
    }
}

pub use explicit::ExplicitStrategy;
pub use semi_implicit::SemiImplicitStrategyGeneric;
```

---

## 任务 3.3: 实现 ExplicitStrategy

**新建文件**: `mh_physics/src/engine/strategy/explicit.rs`

```rust
//! 显式时间积分策略
//!
//! 基于 Godunov 格式的显式有限体积法。

use super::{ExplicitConfig, StepResult, TimeIntegrationStrategy};
use crate::core::{Backend, Scalar};
use crate::mesh::MeshTopology;
use crate::state::ShallowWaterStateGeneric;
use crate::sources::SourceRegistry;
use crate::engine::workspace::SolverWorkspaceGeneric;
use crate::schemes::{HllcSolver, RiemannSolver};

/// 显式时间积分策略
pub struct ExplicitStrategy<B: Backend> {
    /// 配置
    config: ExplicitConfig,
    /// 重力加速度
    gravity: B::Scalar,
    /// 干单元阈值
    h_dry: B::Scalar,
    /// Riemann 求解器
    riemann: HllcSolver,
}

impl<B: Backend> ExplicitStrategy<B> {
    /// 创建显式策略
    pub fn new(config: ExplicitConfig, gravity: f64, h_dry: f64) -> Self {
        use crate::types::NumericalParams;
        let params = NumericalParams::default();
        Self {
            config,
            gravity: B::Scalar::from_f64(gravity),
            h_dry: B::Scalar::from_f64(h_dry),
            riemann: HllcSolver::new(&params, gravity),
        }
    }
    
    /// 计算所有面的通量
    fn compute_fluxes(
        &self,
        state: &ShallowWaterStateGeneric<B>,
        mesh: &dyn MeshTopology<B>,
        workspace: &mut SolverWorkspaceGeneric<B>,
    ) -> B::Scalar {
        let mut max_wave_speed = B::Scalar::from_f64(0.0);
        
        // 获取切片（仅 CPU）
        let h = state.h.as_slice().expect("CPU buffer");
        let hu = state.hu.as_slice().expect("CPU buffer");
        let hv = state.hv.as_slice().expect("CPU buffer");
        let z = state.z.as_slice().expect("CPU buffer");
        
        let flux_h = workspace.flux_h.as_slice_mut().expect("CPU buffer");
        let flux_hu = workspace.flux_hu.as_slice_mut().expect("CPU buffer");
        let flux_hv = workspace.flux_hv.as_slice_mut().expect("CPU buffer");
        
        // 遍历所有面
        for face_idx in mesh.interior_faces() {
            let owner = mesh.face_owner(*face_idx);
            let neighbor = mesh.face_neighbor(*face_idx).unwrap();
            let normal = mesh.face_normal(*face_idx);
            let length = mesh.face_length(*face_idx);
            
            // 获取左右状态
            let h_l = h[owner];
            let h_r = h[neighbor];
            
            // 跳过干面
            if h_l.to_f64() < self.h_dry.to_f64() 
                && h_r.to_f64() < self.h_dry.to_f64() {
                continue;
            }
            
            // 计算速度
            let (u_l, v_l) = if h_l.to_f64() > self.h_dry.to_f64() {
                (hu[owner].to_f64() / h_l.to_f64(), 
                 hv[owner].to_f64() / h_l.to_f64())
            } else {
                (0.0, 0.0)
            };
            
            let (u_r, v_r) = if h_r.to_f64() > self.h_dry.to_f64() {
                (hu[neighbor].to_f64() / h_r.to_f64(), 
                 hv[neighbor].to_f64() / h_r.to_f64())
            } else {
                (0.0, 0.0)
            };
            
            // 静水重构
            let z_face = z[owner].to_f64().max(z[neighbor].to_f64());
            let eta_l = h_l.to_f64() + z[owner].to_f64();
            let eta_r = h_r.to_f64() + z[neighbor].to_f64();
            let h_l_star = (eta_l - z_face).max(0.0);
            let h_r_star = (eta_r - z_face).max(0.0);
            
            // 求解 Riemann 问题
            let vel_l = glam::DVec2::new(u_l, v_l);
            let vel_r = glam::DVec2::new(u_r, v_r);
            let n = glam::DVec2::new(normal[0].to_f64(), normal[1].to_f64());
            
            if let Ok(flux) = self.riemann.solve(h_l_star, h_r_star, vel_l, vel_r, n) {
                let len = length.to_f64();
                
                // 累加到 owner（流出为负）
                flux_h[owner] -= B::Scalar::from_f64(flux.mass * len);
                flux_hu[owner] -= B::Scalar::from_f64(flux.momentum_x * len);
                flux_hv[owner] -= B::Scalar::from_f64(flux.momentum_y * len);
                
                // 累加到 neighbor（流入为正）
                flux_h[neighbor] += B::Scalar::from_f64(flux.mass * len);
                flux_hu[neighbor] += B::Scalar::from_f64(flux.momentum_x * len);
                flux_hv[neighbor] += B::Scalar::from_f64(flux.momentum_y * len);
                
                max_wave_speed = max_wave_speed.max(
                    B::Scalar::from_f64(flux.max_wave_speed)
                );
            }
        }
        
        max_wave_speed
    }
    
    /// 更新状态
    fn update_state(
        &self,
        state: &mut ShallowWaterStateGeneric<B>,
        mesh: &dyn MeshTopology<B>,
        workspace: &SolverWorkspaceGeneric<B>,
        dt: B::Scalar,
    ) {
        let h = state.h.as_slice_mut().expect("CPU buffer");
        let hu = state.hu.as_slice_mut().expect("CPU buffer");
        let hv = state.hv.as_slice_mut().expect("CPU buffer");
        
        let flux_h = workspace.flux_h.as_slice().expect("CPU buffer");
        let flux_hu = workspace.flux_hu.as_slice().expect("CPU buffer");
        let flux_hv = workspace.flux_hv.as_slice().expect("CPU buffer");
        let source_hu = workspace.source_hu.as_slice().expect("CPU buffer");
        let source_hv = workspace.source_hv.as_slice().expect("CPU buffer");
        
        for i in 0..state.n_cells() {
            let area = mesh.cell_area(i);
            let inv_area = B::Scalar::from_f64(1.0) / area;
            
            h[i] = h[i] + dt * flux_h[i] * inv_area;
            hu[i] = hu[i] + dt * (flux_hu[i] * inv_area + source_hu[i]);
            hv[i] = hv[i] + dt * (flux_hv[i] * inv_area + source_hv[i]);
            
            // 强制正性
            if h[i] < B::Scalar::from_f64(0.0) {
                h[i] = B::Scalar::from_f64(0.0);
            }
        }
    }
}

impl<B: Backend> TimeIntegrationStrategy<B> for ExplicitStrategy<B> {
    fn name(&self) -> &'static str {
        "Explicit Godunov"
    }
    
    fn step(
        &mut self,
        state: &mut ShallowWaterStateGeneric<B>,
        mesh: &dyn MeshTopology<B>,
        sources: &SourceRegistry<B>,
        workspace: &mut SolverWorkspaceGeneric<B>,
        dt: B::Scalar,
    ) -> StepResult<B::Scalar> {
        // 1. 重置工作区
        workspace.reset();
        
        // 2. 计算通量
        let max_wave_speed = self.compute_fluxes(state, mesh, workspace);
        
        // 3. 计算源项
        sources.compute_all(state, workspace, dt);
        
        // 4. 更新状态
        self.update_state(state, mesh, workspace, dt);
        
        // 5. 统计干单元
        let dry_cells = state.h.as_slice()
            .map(|h| h.iter().filter(|&&x| x.to_f64() < self.h_dry.to_f64()).count())
            .unwrap_or(0);
        
        StepResult {
            dt_used: dt,
            max_wave_speed,
            dry_cells,
            limited_cells: 0,
            converged: true,
            iterations: 0,
        }
    }
    
    fn compute_stable_dt(
        &self,
        state: &ShallowWaterStateGeneric<B>,
        mesh: &dyn MeshTopology<B>,
        cfl: B::Scalar,
    ) -> B::Scalar {
        let h = state.h.as_slice().expect("CPU buffer");
        let hu = state.hu.as_slice().expect("CPU buffer");
        let hv = state.hv.as_slice().expect("CPU buffer");
        
        let mut dt_min = B::Scalar::from_f64(f64::MAX);
        let g = self.gravity.to_f64();
        
        for i in 0..state.n_cells() {
            let hi = h[i].to_f64();
            if hi < self.h_dry.to_f64() {
                continue;
            }
            
            let u = hu[i].to_f64() / hi;
            let v = hv[i].to_f64() / hi;
            let c = (g * hi).sqrt();
            let vel = (u * u + v * v).sqrt() + c;
            
            let area = mesh.cell_area(i).to_f64();
            let dx = area.sqrt();
            
            if vel > 1e-14 && dx > 1e-14 {
                let dt_local = cfl.to_f64() * dx / vel;
                dt_min = dt_min.min(B::Scalar::from_f64(dt_local));
            }
        }
        
        dt_min
    }
    
    fn recommended_cfl(&self) -> B::Scalar {
        B::Scalar::from_f64(self.config.cfl.max(0.5))
    }
}
```

---

## 任务 3.4: 实现 SemiImplicitStrategyGeneric

**新建文件**: `mh_physics/src/engine/strategy/semi_implicit.rs`

（从现有 `semi_implicit.rs` 迁移并泛型化，保持核心算法不变）

关键改动点：
1. 将 `f64` 替换为 `B::Scalar`
2. 将 `AlignedVec<f64>` 替换为 `B::Buffer<B::Scalar>`
3. 实现 `TimeIntegrationStrategy<B>` trait

---

## 任务 3.5: 创建 SourceRegistry

**新建文件**: `mh_physics/src/sources/registry.rs`

```rust
//! 源项注册表
//!
//! 统一管理所有源项。

use crate::core::{Backend, Scalar};
use crate::state::ShallowWaterStateGeneric;
use crate::engine::workspace::SolverWorkspaceGeneric;
use super::traits::{SourceTerm, SourceContribution, SourceContext};

/// 源项注册表
pub struct SourceRegistry<B: Backend> {
    /// 已注册的源项
    sources: Vec<Box<dyn SourceTermGeneric<B>>>,
}

/// 泛型源项 trait
pub trait SourceTermGeneric<B: Backend>: Send + Sync {
    /// 源项名称
    fn name(&self) -> &'static str;
    
    /// 是否启用
    fn is_enabled(&self) -> bool;
    
    /// 计算单个单元的源项
    fn compute_cell(
        &self,
        state: &ShallowWaterStateGeneric<B>,
        cell: usize,
        dt: B::Scalar,
    ) -> SourceContributionGeneric<B::Scalar>;
    
    /// 批量计算
    fn compute_all(
        &self,
        state: &ShallowWaterStateGeneric<B>,
        workspace: &mut SolverWorkspaceGeneric<B>,
        dt: B::Scalar,
    );
    
    /// 是否局部隐式
    fn is_locally_implicit(&self) -> bool {
        false
    }
}

/// 泛型源项贡献
#[derive(Debug, Clone, Copy, Default)]
pub struct SourceContributionGeneric<S: Scalar> {
    pub s_h: S,
    pub s_hu: S,
    pub s_hv: S,
}

impl<B: Backend> SourceRegistry<B> {
    /// 创建空注册表
    pub fn new() -> Self {
        Self { sources: Vec::new() }
    }
    
    /// 注册源项
    pub fn register(&mut self, source: Box<dyn SourceTermGeneric<B>>) {
        self.sources.push(source);
    }
    
    /// 计算所有源项
    pub fn compute_all(
        &self,
        state: &ShallowWaterStateGeneric<B>,
        workspace: &mut SolverWorkspaceGeneric<B>,
        dt: B::Scalar,
    ) {
        for source in &self.sources {
            if source.is_enabled() {
                source.compute_all(state, workspace, dt);
            }
        }
    }
    
    /// 获取源项数量
    pub fn len(&self) -> usize {
        self.sources.len()
    }
    
    /// 是否为空
    pub fn is_empty(&self) -> bool {
        self.sources.is_empty()
    }
}

impl<B: Backend> Default for SourceRegistry<B> {
    fn default() -> Self {
        Self::new()
    }
}
```

---

## 任务 3.6: 重构 ShallowWaterSolver

**改动文件**: `mh_physics/src/engine/solver.rs`

将现有求解器重构为策略调度器：

```rust
use crate::core::{Backend, CpuBackend};
use crate::mesh::MeshTopology;
use crate::state::ShallowWaterStateGeneric;
use crate::sources::SourceRegistry;
use super::strategy::{TimeIntegrationStrategy, StrategyKind, StepResult};
use super::workspace::SolverWorkspaceGeneric;
use std::sync::Arc;

/// 泛型浅水求解器
pub struct ShallowWaterSolverGeneric<B: Backend> {
    /// 网格
    mesh: Arc<dyn MeshTopology<B>>,
    /// 状态
    state: ShallowWaterStateGeneric<B>,
    /// 时间积分策略
    strategy: Box<dyn TimeIntegrationStrategy<B>>,
    /// 工作区
    workspace: SolverWorkspaceGeneric<B>,
    /// 源项注册表
    sources: SourceRegistry<B>,
    /// 配置
    config: SolverConfig,
}

impl<B: Backend> ShallowWaterSolverGeneric<B> {
    /// 创建求解器
    pub fn new(
        mesh: Arc<dyn MeshTopology<B>>,
        strategy: Box<dyn TimeIntegrationStrategy<B>>,
        config: SolverConfig,
    ) -> Self {
        let n_cells = mesh.n_cells();
        let n_faces = mesh.n_faces();
        
        Self {
            state: ShallowWaterStateGeneric::new(n_cells),
            workspace: SolverWorkspaceGeneric::new(n_cells, n_faces),
            sources: SourceRegistry::new(),
            mesh,
            strategy,
            config,
        }
    }
    
    /// 执行单步
    pub fn step(&mut self, dt: B::Scalar) -> StepResult<B::Scalar> {
        self.strategy.step(
            &mut self.state,
            self.mesh.as_ref(),
            &self.sources,
            &mut self.workspace,
            dt,
        )
    }
    
    /// 计算稳定时间步长
    pub fn compute_dt(&self) -> B::Scalar {
        self.strategy.compute_stable_dt(
            &self.state,
            self.mesh.as_ref(),
            self.strategy.recommended_cfl(),
        )
    }
    
    /// 切换策略
    pub fn set_strategy(&mut self, strategy: Box<dyn TimeIntegrationStrategy<B>>) {
        self.strategy = strategy;
    }
    
    /// 获取状态引用
    pub fn state(&self) -> &ShallowWaterStateGeneric<B> {
        &self.state
    }
    
    /// 获取状态可变引用
    pub fn state_mut(&mut self) -> &mut ShallowWaterStateGeneric<B> {
        &mut self.state
    }
    
    /// 注册源项
    pub fn register_source(&mut self, source: Box<dyn crate::sources::SourceTermGeneric<B>>) {
        self.sources.register(source);
    }
}

/// 类型别名
pub type ShallowWaterSolverDefault = ShallowWaterSolverGeneric<CpuBackend<f64>>;
```

---

## 任务 3.7: 更新 engine/mod.rs

**改动文件**: `mh_physics/src/engine/mod.rs`

```rust
pub mod strategy;
pub mod workspace;

// 重导出
pub use strategy::{
    TimeIntegrationStrategy, StrategyKind, StepResult,
    ExplicitStrategy, ExplicitConfig,
    SemiImplicitStrategyGeneric, SemiImplicitConfig,
};
pub use workspace::SolverWorkspaceGeneric;
pub use solver::{ShallowWaterSolverGeneric, ShallowWaterSolverDefault};
```

---

## 验证清单

- [ ] `cargo check -p mh_physics` 通过
- [ ] `cargo test -p mh_physics` 通过
- [ ] ExplicitStrategy 单独运行正确
- [ ] SemiImplicitStrategyGeneric 单独运行正确
- [ ] 策略切换功能正常
- [ ] dambreak 测试通过
- [ ] thacker 测试通过

```bash
cd marihydro
cargo check -p mh_physics
cargo test -p mh_physics
cargo test -p mh_physics strategy::
cargo test -p mh_physics -- dambreak
cargo test -p mh_physics -- thacker
```

---

## 时间估计

| 任务 | 预计时间 |
|------|----------|
| 任务 3.1 | 3 小时 |
| 任务 3.2 | 3 小时 |
| 任务 3.3 | 6 小时 |
| 任务 3.4 | 8 小时 |
| 任务 3.5 | 3 小时 |
| 任务 3.6 | 4 小时 |
| 任务 3.7 | 1 小时 |
| 测试与验证 | 4 小时 |
| **总计** | **~32 小时** |
