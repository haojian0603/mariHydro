# Phase 0-1: 清理与核心抽象层

## 概述

本阶段包含两个子阶段：
- **Phase 0 (第1周)**: 清理死代码，消除误导性接口
- **Phase 1 (第2-3周)**: 建立 Backend 和 Buffer 抽象，实现 CpuBackend

## Phase 0: 清理与标准化

### 目标
移除死代码，消除误导性接口，为重构铺路。

### 任务 0.1: 删除 k_epsilon 死代码

**改动文件**:
- `mh_physics/src/sources/turbulence/k_epsilon.rs` → 删除
- `mh_physics/src/sources/turbulence/mod.rs` → 移除 k_epsilon 导出

**具体操作**:

1. 删除文件 `mh_physics/src/sources/turbulence/k_epsilon.rs`

2. 修改 `mh_physics/src/sources/turbulence/mod.rs`:
```rust
// 删除以下行:
mod k_epsilon;
pub use k_epsilon::{KEpsilonModel, KEpsilonParams};

// 添加注释说明:
//! # 维度适用性
//!
//! | 模型 | 2D 浅水 | 说明 |
//! |------|---------|------|
//! | Smagorinsky | ✓ | 适用于深度平均湍流 |
//!
//! **注意**: k-ε 模型已移除，因为浅水方程是深度平均方程，
//! 直接应用 3D 湍流模型在物理上是不正确的。
```

**验证**: `cargo check -p mh_physics`

---

### 任务 0.2: 清理 sources/mod.rs 导出

**改动文件**:
- `mh_physics/src/sources/mod.rs`

**具体操作**:

移除 k-ε 相关导出:
```rust
// 删除以下行:
pub use turbulence::{
    // ...
    // k-ε (3D)
    KEpsilonModel, KEpsilonParams,
    // ...
};

// 修改为:
pub use turbulence::{
    // Smagorinsky (2D)
    TurbulenceModel, TurbulenceConfig, SmagorinskySolver,
    VelocityGradient,
    DEFAULT_SMAGORINSKY_CONSTANT, MIN_EDDY_VISCOSITY, MAX_EDDY_VISCOSITY,
    // 通用 trait
    TurbulenceClosure,
};
```

**验证**: `cargo check -p mh_physics`

---

### 任务 0.3: 重命名 requires_implicit_treatment

**改动文件**:
- `mh_physics/src/sources/traits.rs`
- `mh_physics/src/sources/friction.rs`
- `mh_physics/src/sources/vegetation.rs`
- 其他实现 SourceTerm 的文件

**具体操作**:

1. 在 `traits.rs` 中重命名方法:
```rust
// 旧接口 (保留但标记废弃):
#[deprecated(since = "0.5.0", note = "use is_locally_implicit() instead")]
fn requires_implicit_treatment(&self) -> bool {
    self.is_locally_implicit()
}

// 新接口:
/// 源项是否使用局部隐式处理
/// 
/// 局部隐式意味着源项内部处理刚性（如摩擦的 1/(1+dt*γ)），
/// 而非需要全局隐式求解器。
fn is_locally_implicit(&self) -> bool {
    false
}
```

2. 更新所有实现类使用新方法名

**验证**: `cargo check -p mh_physics && cargo test -p mh_physics`

---

### 任务 0.4: 清理 implicit.rs 遗留代码

**改动文件**:
- `mh_physics/src/sources/implicit.rs`

**具体操作**:

删除未使用的 `ImplicitMethod` 枚举，保留 `DampingCoefficient`:
```rust
// 删除:
#[deprecated(since = "0.5.0", note = "半隐式策略已迁移到 engine/strategy")]
pub enum ImplicitMethod {
    // ...
}

// 保留:
/// 阻尼系数计算
pub trait DampingCoefficient: Send + Sync {
    fn compute(&self, h: f64, u: f64, v: f64, dt: f64) -> f64;
}

pub struct ManningDamping { /* ... */ }
pub struct ChezyDamping { /* ... */ }
```

**验证**: `cargo check -p mh_physics`

---

## Phase 1: 核心抽象层

### 目标
建立 Backend 和 Buffer 抽象，实现 CpuBackend<f32/f64>。

### 任务 1.1: 创建 core 模块结构

**新建文件**:
- `mh_physics/src/core/mod.rs`
- `mh_physics/src/core/scalar.rs`
- `mh_physics/src/core/buffer.rs`
- `mh_physics/src/core/backend.rs`
- `mh_physics/src/core/dimension.rs`

**改动文件**:
- `mh_physics/src/lib.rs` → 添加 `pub mod core;`

---

### 任务 1.2: 实现 Scalar trait

**文件**: `mh_physics/src/core/scalar.rs`

```rust
//! 标量类型抽象
//!
//! 提供 f32/f64 的统一接口，支持编译期精度选择。

use bytemuck::Pod;
use num_traits::{Float, FromPrimitive, NumAssign};
use std::fmt::{Debug, Display};
use std::iter::Sum;

/// 标量类型约束
pub trait Scalar:
    Float
    + Pod
    + Default
    + Debug
    + Display
    + Send
    + Sync
    + NumAssign
    + FromPrimitive
    + Sum
    + 'static
{
    /// 类型名称
    fn type_name() -> &'static str;
    
    /// 机器精度
    fn epsilon() -> Self;
    
    /// 最小正规数
    fn min_positive() -> Self;
    
    /// 从 f64 转换
    fn from_f64(v: f64) -> Self;
    
    /// 转换为 f64
    fn to_f64(self) -> f64;
    
    /// 平方根
    fn sqrt(self) -> Self;
    
    /// 绝对值
    fn abs(self) -> Self;
    
    /// 最大值
    fn max(self, other: Self) -> Self;
    
    /// 最小值
    fn min(self, other: Self) -> Self;
    
    /// 钳位
    fn clamp(self, min: Self, max: Self) -> Self;
}

impl Scalar for f32 {
    fn type_name() -> &'static str { "f32" }
    fn epsilon() -> Self { f32::EPSILON }
    fn min_positive() -> Self { f32::MIN_POSITIVE }
    fn from_f64(v: f64) -> Self { v as f32 }
    fn to_f64(self) -> f64 { self as f64 }
    fn sqrt(self) -> Self { f32::sqrt(self) }
    fn abs(self) -> Self { f32::abs(self) }
    fn max(self, other: Self) -> Self { f32::max(self, other) }
    fn min(self, other: Self) -> Self { f32::min(self, other) }
    fn clamp(self, min: Self, max: Self) -> Self { f32::clamp(self, min, max) }
}

impl Scalar for f64 {
    fn type_name() -> &'static str { "f64" }
    fn epsilon() -> Self { f64::EPSILON }
    fn min_positive() -> Self { f64::MIN_POSITIVE }
    fn from_f64(v: f64) -> Self { v }
    fn to_f64(self) -> f64 { self }
    fn sqrt(self) -> Self { f64::sqrt(self) }
    fn abs(self) -> Self { f64::abs(self) }
    fn max(self, other: Self) -> Self { f64::max(self, other) }
    fn min(self, other: Self) -> Self { f64::min(self, other) }
    fn clamp(self, min: Self, max: Self) -> Self { f64::clamp(self, min, max) }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_scalar_f32() {
        let x: f32 = Scalar::from_f64(3.14);
        assert!((x - 3.14f32).abs() < 1e-6);
    }

    #[test]
    fn test_scalar_f64() {
        let x: f64 = Scalar::from_f64(3.14);
        assert!((x - 3.14f64).abs() < 1e-14);
    }
}
```

---

### 任务 1.3: 实现 DeviceBuffer trait

**文件**: `mh_physics/src/core/buffer.rs`

```rust
//! 设备缓冲区抽象
//!
//! 提供 CPU/GPU 统一的缓冲区接口。

use bytemuck::Pod;
use std::ops::{Index, IndexMut};

/// 设备缓冲区接口
pub trait DeviceBuffer<T: Pod>: Clone + Send + Sync + Sized {
    /// 缓冲区长度
    fn len(&self) -> usize;
    
    /// 是否为空
    fn is_empty(&self) -> bool {
        self.len() == 0
    }
    
    /// 从 Host 切片复制数据
    fn copy_from_slice(&mut self, src: &[T]);
    
    /// 复制到 Host Vec
    fn copy_to_vec(&self) -> Vec<T>;
    
    /// 获取可变切片（仅 CPU 有效，GPU 返回 None）
    fn as_slice(&self) -> Option<&[T]>;
    
    /// 获取可变切片（仅 CPU 有效，GPU 返回 None）
    fn as_slice_mut(&mut self) -> Option<&mut [T]>;
    
    /// 填充值
    fn fill(&mut self, value: T);
}

/// Vec<T> 作为 CPU 缓冲区
impl<T: Pod + Clone> DeviceBuffer<T> for Vec<T> {
    fn len(&self) -> usize {
        Vec::len(self)
    }
    
    fn copy_from_slice(&mut self, src: &[T]) {
        self.clear();
        self.extend_from_slice(src);
    }
    
    fn copy_to_vec(&self) -> Vec<T> {
        self.clone()
    }
    
    fn as_slice(&self) -> Option<&[T]> {
        Some(self.as_ref())
    }
    
    fn as_slice_mut(&mut self) -> Option<&mut [T]> {
        Some(self.as_mut())
    }
    
    fn fill(&mut self, value: T) {
        self.iter_mut().for_each(|x| *x = value.clone());
    }
}

/// AlignedVec 适配器（复用现有类型）
use mh_foundation::memory::AlignedVec;

impl<T: Pod + Clone + Default> DeviceBuffer<T> for AlignedVec<T> {
    fn len(&self) -> usize {
        AlignedVec::len(self)
    }
    
    fn copy_from_slice(&mut self, src: &[T]) {
        self.as_mut_slice().copy_from_slice(src);
    }
    
    fn copy_to_vec(&self) -> Vec<T> {
        self.as_slice().to_vec()
    }
    
    fn as_slice(&self) -> Option<&[T]> {
        Some(AlignedVec::as_slice(self))
    }
    
    fn as_slice_mut(&mut self) -> Option<&mut [T]> {
        Some(AlignedVec::as_mut_slice(self))
    }
    
    fn fill(&mut self, value: T) {
        AlignedVec::fill(self, value);
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_vec_buffer() {
        let mut buf: Vec<f64> = vec![0.0; 10];
        buf.fill(1.0);
        assert_eq!(buf[0], 1.0);
        assert_eq!(buf.len(), 10);
    }
}
```

---

### 任务 1.4: 实现 Backend trait

**文件**: `mh_physics/src/core/backend.rs`

```rust
//! 计算后端抽象
//!
//! 提供 CPU/GPU 统一的计算接口。

use super::buffer::DeviceBuffer;
use super::scalar::Scalar;
use bytemuck::Pod;
use std::fmt::Debug;
use std::marker::PhantomData;

/// 计算后端 trait
pub trait Backend: Clone + Send + Sync + Debug + 'static {
    /// 标量类型
    type Scalar: Scalar;
    
    /// 缓冲区类型
    type Buffer<T: Pod>: DeviceBuffer<T>;
    
    /// 后端名称
    fn name() -> &'static str;
    
    /// 分配缓冲区
    fn alloc<T: Pod + Clone + Default>(len: usize) -> Self::Buffer<T>;
    
    /// 分配并初始化缓冲区
    fn alloc_init<T: Pod + Clone>(len: usize, init: T) -> Self::Buffer<T>;
    
    /// 同步操作（GPU 需要，CPU 空实现）
    fn synchronize() {}
    
    // ========== BLAS Level 1 算子 ==========
    
    /// y = alpha * x + y (AXPY)
    fn axpy(
        alpha: Self::Scalar,
        x: &Self::Buffer<Self::Scalar>,
        y: &mut Self::Buffer<Self::Scalar>,
    );
    
    /// dot = x · y
    fn dot(
        x: &Self::Buffer<Self::Scalar>,
        y: &Self::Buffer<Self::Scalar>,
    ) -> Self::Scalar;
    
    /// y = x (复制)
    fn copy(
        src: &Self::Buffer<Self::Scalar>,
        dst: &mut Self::Buffer<Self::Scalar>,
    );
    
    /// 归约：最大值
    fn reduce_max(x: &Self::Buffer<Self::Scalar>) -> Self::Scalar;
    
    /// 归约：求和
    fn reduce_sum(x: &Self::Buffer<Self::Scalar>) -> Self::Scalar;
    
    /// 缩放: x = alpha * x
    fn scale(alpha: Self::Scalar, x: &mut Self::Buffer<Self::Scalar>);
}

/// CPU 后端（泛型精度）
#[derive(Debug, Clone, Default)]
pub struct CpuBackend<S: Scalar> {
    _marker: PhantomData<S>,
}

impl<S: Scalar> CpuBackend<S> {
    pub fn new() -> Self {
        Self { _marker: PhantomData }
    }
}

impl Backend for CpuBackend<f32> {
    type Scalar = f32;
    type Buffer<T: Pod> = Vec<T>;
    
    fn name() -> &'static str { "CPU-f32" }
    
    fn alloc<T: Pod + Clone + Default>(len: usize) -> Self::Buffer<T> {
        vec![T::default(); len]
    }
    
    fn alloc_init<T: Pod + Clone>(len: usize, init: T) -> Self::Buffer<T> {
        vec![init; len]
    }
    
    fn axpy(alpha: f32, x: &Vec<f32>, y: &mut Vec<f32>) {
        debug_assert_eq!(x.len(), y.len());
        for (yi, xi) in y.iter_mut().zip(x.iter()) {
            *yi += alpha * xi;
        }
    }
    
    fn dot(x: &Vec<f32>, y: &Vec<f32>) -> f32 {
        debug_assert_eq!(x.len(), y.len());
        x.iter().zip(y.iter()).map(|(a, b)| a * b).sum()
    }
    
    fn copy(src: &Vec<f32>, dst: &mut Vec<f32>) {
        dst.copy_from_slice(src);
    }
    
    fn reduce_max(x: &Vec<f32>) -> f32 {
        x.iter().cloned().fold(f32::NEG_INFINITY, f32::max)
    }
    
    fn reduce_sum(x: &Vec<f32>) -> f32 {
        x.iter().sum()
    }
    
    fn scale(alpha: f32, x: &mut Vec<f32>) {
        for xi in x.iter_mut() {
            *xi *= alpha;
        }
    }
}

impl Backend for CpuBackend<f64> {
    type Scalar = f64;
    type Buffer<T: Pod> = Vec<T>;
    
    fn name() -> &'static str { "CPU-f64" }
    
    fn alloc<T: Pod + Clone + Default>(len: usize) -> Self::Buffer<T> {
        vec![T::default(); len]
    }
    
    fn alloc_init<T: Pod + Clone>(len: usize, init: T) -> Self::Buffer<T> {
        vec![init; len]
    }
    
    fn axpy(alpha: f64, x: &Vec<f64>, y: &mut Vec<f64>) {
        debug_assert_eq!(x.len(), y.len());
        for (yi, xi) in y.iter_mut().zip(x.iter()) {
            *yi += alpha * xi;
        }
    }
    
    fn dot(x: &Vec<f64>, y: &Vec<f64>) -> f64 {
        debug_assert_eq!(x.len(), y.len());
        x.iter().zip(y.iter()).map(|(a, b)| a * b).sum()
    }
    
    fn copy(src: &Vec<f64>, dst: &mut Vec<f64>) {
        dst.copy_from_slice(src);
    }
    
    fn reduce_max(x: &Vec<f64>) -> f64 {
        x.iter().cloned().fold(f64::NEG_INFINITY, f64::max)
    }
    
    fn reduce_sum(x: &Vec<f64>) -> f64 {
        x.iter().sum()
    }
    
    fn scale(alpha: f64, x: &mut Vec<f64>) {
        for xi in x.iter_mut() {
            *xi *= alpha;
        }
    }
}

/// 类型别名：默认后端
pub type DefaultBackend = CpuBackend<f64>;

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_cpu_backend_f64_axpy() {
        let x: Vec<f64> = vec![1.0, 2.0, 3.0];
        let mut y: Vec<f64> = vec![4.0, 5.0, 6.0];
        CpuBackend::<f64>::axpy(2.0, &x, &mut y);
        assert_eq!(y, vec![6.0, 9.0, 12.0]);
    }

    #[test]
    fn test_cpu_backend_f64_dot() {
        let x: Vec<f64> = vec![1.0, 2.0, 3.0];
        let y: Vec<f64> = vec![4.0, 5.0, 6.0];
        let result = CpuBackend::<f64>::dot(&x, &y);
        assert!((result - 32.0).abs() < 1e-10);
    }

    #[test]
    fn test_cpu_backend_f32() {
        let x: Vec<f32> = vec![1.0, 2.0, 3.0];
        let mut y: Vec<f32> = vec![0.0, 0.0, 0.0];
        CpuBackend::<f32>::copy(&x, &mut y);
        assert_eq!(y, x);
    }
}
```

---

### 任务 1.5: 实现 Dimension marker

**文件**: `mh_physics/src/core/dimension.rs`

```rust
//! 维度标记
//!
//! 提供编译期维度区分，用于类型安全的 2D/3D 代码。

use std::fmt::Debug;

/// 维度标记 trait
pub trait Dimension: Debug + Clone + Copy + Send + Sync + 'static {
    /// 维度数
    const NDIM: usize;
    
    /// 维度名称
    fn name() -> &'static str;
}

/// 2D 维度标记
#[derive(Debug, Clone, Copy, Default)]
pub struct D2;

impl Dimension for D2 {
    const NDIM: usize = 2;
    
    fn name() -> &'static str { "2D" }
}

/// 3D 维度标记（预留，当前不实现具体算法）
#[derive(Debug, Clone, Copy, Default)]
pub struct D3;

impl Dimension for D3 {
    const NDIM: usize = 3;
    
    fn name() -> &'static str { "3D" }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_dimension_2d() {
        assert_eq!(D2::NDIM, 2);
        assert_eq!(D2::name(), "2D");
    }

    #[test]
    fn test_dimension_3d() {
        assert_eq!(D3::NDIM, 3);
        assert_eq!(D3::name(), "3D");
    }
}
```

---

### 任务 1.6: 创建 core/mod.rs

**文件**: `mh_physics/src/core/mod.rs`

```rust
//! 核心抽象层
//!
//! 提供计算后端、缓冲区、标量类型等基础抽象。
//!
//! # 模块结构
//!
//! - [`scalar`]: 标量类型抽象 (f32/f64)
//! - [`buffer`]: 设备缓冲区抽象
//! - [`backend`]: 计算后端抽象 (CPU/GPU)
//! - [`dimension`]: 维度标记 (2D/3D)
//!
//! # 使用示例
//!
//! ```ignore
//! use mh_physics::core::{Backend, CpuBackend, Scalar};
//!
//! // 使用 f64 精度的 CPU 后端
//! type B = CpuBackend<f64>;
//!
//! let x: <B as Backend>::Buffer<f64> = B::alloc_init(100, 1.0);
//! let mut y: <B as Backend>::Buffer<f64> = B::alloc_init(100, 2.0);
//! B::axpy(0.5, &x, &mut y);
//! ```

pub mod scalar;
pub mod buffer;
pub mod backend;
pub mod dimension;

// 重导出常用类型
pub use scalar::Scalar;
pub use buffer::DeviceBuffer;
pub use backend::{Backend, CpuBackend, DefaultBackend};
pub use dimension::{Dimension, D2, D3};
```

---

### 任务 1.7: 更新 lib.rs

**改动文件**: `mh_physics/src/lib.rs`

```rust
// 在模块声明区域添加:
pub mod core;

// 在重导出区域添加:
pub use core::{Backend, CpuBackend, DefaultBackend, Scalar, DeviceBuffer, D2, D3};
```

---

## 验证清单

### Phase 0 验证
- [ ] `cargo check -p mh_physics` 通过
- [ ] `cargo test -p mh_physics` 通过
- [ ] k_epsilon.rs 已删除
- [ ] requires_implicit_treatment 已重命名

### Phase 1 验证
- [ ] `cargo check -p mh_physics` 通过
- [ ] `cargo test -p mh_physics` 通过
- [ ] Backend trait 单元测试通过
- [ ] CpuBackend<f32> 和 CpuBackend<f64> 都可用

```bash
# 完整验证命令
cd marihydro
cargo check -p mh_physics
cargo test -p mh_physics
cargo test -p mh_physics core::
```

---

## 依赖关系

```
Phase 0 (清理)
    │
    ▼
Phase 1 (核心抽象)
    │
    ├── scalar.rs (无依赖)
    │
    ├── buffer.rs (依赖 scalar)
    │
    ├── backend.rs (依赖 scalar, buffer)
    │
    └── dimension.rs (无依赖)
```

---

## 风险与缓解

| 风险 | 影响 | 缓解措施 |
|------|------|----------|
| bytemuck 版本冲突 | 编译失败 | 检查 Cargo.toml 依赖版本 |
| AlignedVec 接口变化 | 适配器失效 | 使用 wrapper 模式隔离 |
| 泛型爆炸 | 编译时间增加 | 使用类型别名减少泛型传播 |

---

## 时间估计

| 任务 | 预计时间 |
|------|----------|
| Phase 0 全部 | 2-3 小时 |
| 任务 1.1-1.2 | 2 小时 |
| 任务 1.3 | 2 小时 |
| 任务 1.4 | 4 小时 |
| 任务 1.5-1.7 | 1 小时 |
| 测试与验证 | 2 小时 |
| **总计** | **~13 小时** |
