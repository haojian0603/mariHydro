# Phase 4-5: 2.5D扩展与GPU准备

## 概述

**Phase 4 (第9-10周)**: 实现垂向恢复器和2.5D泥沙输运  
**Phase 5 (第11-12周)**: 完成GPU迁移准备工作

## 前置依赖

- Phase 0-3 完成
- Backend trait 和 MeshTopology trait 可用
- 策略模式求解器可用

---

# Phase 4: 2.5D扩展

## 任务 4.1: 创建 ProfileRestorer

**新建文件**: `mh_physics/src/vertical/profile.rs`

```rust
//! 垂向剖面恢复器
//!
//! 从2D深度平均状态恢复垂向速度剖面。

use crate::core::{Backend, Scalar};
use crate::state::ShallowWaterStateGeneric;
use crate::vertical::sigma::SigmaCoordinate;

/// 垂向剖面
#[derive(Debug, Clone)]
pub struct VerticalProfile<B: Backend> {
    /// 单元数量
    n_cells: usize,
    /// 层数
    n_layers: usize,
    /// 各层 u 速度 [n_cells * n_layers]
    pub u_layers: B::Buffer<B::Scalar>,
    /// 各层 v 速度 [n_cells * n_layers]
    pub v_layers: B::Buffer<B::Scalar>,
    /// 各层高度 [n_cells * n_layers]
    pub z_layers: B::Buffer<B::Scalar>,
}

impl<B: Backend> VerticalProfile<B> {
    /// 创建垂向剖面
    pub fn new(n_cells: usize, n_layers: usize) -> Self {
        let total = n_cells * n_layers;
        Self {
            n_cells,
            n_layers,
            u_layers: B::alloc(total),
            v_layers: B::alloc(total),
            z_layers: B::alloc(total),
        }
    }
    
    /// 获取索引
    #[inline]
    pub fn index(&self, cell: usize, layer: usize) -> usize {
        cell * self.n_layers + layer
    }
    
    /// 设置层速度
    pub fn set(&mut self, cell: usize, layer: usize, u: B::Scalar, v: B::Scalar) {
        let idx = self.index(cell, layer);
        if let Some(u_slice) = self.u_layers.as_slice_mut() {
            u_slice[idx] = u;
        }
        if let Some(v_slice) = self.v_layers.as_slice_mut() {
            v_slice[idx] = v;
        }
    }
}

/// 剖面恢复方法
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ProfileMethod {
    /// 对数律剖面
    Logarithmic,
    /// 抛物线剖面
    Parabolic,
    /// 均匀剖面
    Uniform,
}

/// 垂向剖面恢复器
pub struct ProfileRestorer<B: Backend> {
    /// σ坐标
    sigma: SigmaCoordinate,
    /// 糙率 [n_cells]
    roughness: B::Buffer<B::Scalar>,
    /// 层数
    n_layers: usize,
    /// 恢复方法
    method: ProfileMethod,
    /// von Karman 常数
    von_karman: B::Scalar,
}

/// von Karman 常数
const VON_KARMAN: f64 = 0.41;

impl<B: Backend> ProfileRestorer<B> {
    /// 创建恢复器
    pub fn new(n_cells: usize, n_layers: usize, method: ProfileMethod) -> Self {
        Self {
            sigma: SigmaCoordinate::uniform(n_layers),
            roughness: B::alloc_init(n_cells, B::Scalar::from_f64(0.001)),
            n_layers,
            method,
            von_karman: B::Scalar::from_f64(VON_KARMAN),
        }
    }
    
    /// 设置糙率
    pub fn set_roughness(&mut self, cell: usize, z0: B::Scalar) {
        if let Some(slice) = self.roughness.as_slice_mut() {
            slice[cell] = z0;
        }
    }
    
    /// 从2D状态恢复垂向剖面
    pub fn restore(
        &self,
        state: &ShallowWaterStateGeneric<B>,
        output: &mut VerticalProfile<B>,
    ) {
        let h = state.h.as_slice().expect("CPU buffer");
        let hu = state.hu.as_slice().expect("CPU buffer");
        let hv = state.hv.as_slice().expect("CPU buffer");
        let z = state.z.as_slice().expect("CPU buffer");
        let roughness = self.roughness.as_slice().expect("CPU buffer");
        
        let u_out = output.u_layers.as_slice_mut().expect("CPU buffer");
        let v_out = output.v_layers.as_slice_mut().expect("CPU buffer");
        let z_out = output.z_layers.as_slice_mut().expect("CPU buffer");
        
        let h_min = B::Scalar::from_f64(1e-6);
        
        for cell in 0..state.n_cells() {
            let hi = h[cell];
            
            // 干单元跳过
            if hi < h_min {
                for k in 0..self.n_layers {
                    let idx = output.index(cell, k);
                    u_out[idx] = B::Scalar::from_f64(0.0);
                    v_out[idx] = B::Scalar::from_f64(0.0);
                    z_out[idx] = z[cell];
                }
                continue;
            }
            
            // 深度平均速度
            let u_avg = hu[cell] / hi;
            let v_avg = hv[cell] / hi;
            let speed_avg = (u_avg * u_avg + v_avg * v_avg).sqrt();
            
            // 速度方向
            let (dir_u, dir_v) = if speed_avg > B::Scalar::from_f64(1e-10) {
                (u_avg / speed_avg, v_avg / speed_avg)
            } else {
                (B::Scalar::from_f64(1.0), B::Scalar::from_f64(0.0))
            };
            
            // 摩擦速度估计
            let z0 = roughness[cell];
            let u_star = self.estimate_friction_velocity(speed_avg, hi, z0);
            
            // 恢复各层速度
            for k in 0..self.n_layers {
                let idx = output.index(cell, k);
                let sigma_k = self.sigma.sigma_at_layer(k);
                let z_k = z[cell] + hi * sigma_k;
                z_out[idx] = z_k;
                
                let speed_k = match self.method {
                    ProfileMethod::Logarithmic => {
                        self.log_profile(u_star, z_k - z[cell], z0)
                    }
                    ProfileMethod::Parabolic => {
                        self.parabolic_profile(speed_avg, sigma_k)
                    }
                    ProfileMethod::Uniform => {
                        speed_avg
                    }
                };
                
                u_out[idx] = speed_k * dir_u;
                v_out[idx] = speed_k * dir_v;
            }
        }
    }
    
    /// 估计摩擦速度
    fn estimate_friction_velocity(
        &self,
        u_avg: B::Scalar,
        h: B::Scalar,
        z0: B::Scalar,
    ) -> B::Scalar {
        // u_avg = u* / κ * (ln(h/z0) - 1)
        // 简化: u* ≈ κ * u_avg / ln(h/z0)
        let ratio = h / z0;
        if ratio > B::Scalar::from_f64(1.0) {
            self.von_karman * u_avg / ratio.to_f64().ln().max(1.0).into()
        } else {
            B::Scalar::from_f64(0.0)
        }
    }
    
    /// 对数律剖面
    fn log_profile(&self, u_star: B::Scalar, z: B::Scalar, z0: B::Scalar) -> B::Scalar {
        if z > z0 {
            u_star / self.von_karman * (z / z0).to_f64().ln().into()
        } else {
            B::Scalar::from_f64(0.0)
        }
    }
    
    /// 抛物线剖面
    fn parabolic_profile(&self, u_avg: B::Scalar, sigma: B::Scalar) -> B::Scalar {
        // u(σ) = 1.5 * u_avg * (1 - σ²)
        let one = B::Scalar::from_f64(1.0);
        let factor = B::Scalar::from_f64(1.5);
        factor * u_avg * (one - sigma * sigma)
    }
}
```

---

## 任务 4.2: 创建 2.5D 泥沙输运

**新建文件**: `mh_physics/src/sediment/transport_2_5d.rs`

```rust
//! 2.5D 泥沙输运
//!
//! 基于垂向剖面恢复的泥沙输运计算。

use crate::core::{Backend, Scalar};
use crate::state::ShallowWaterStateGeneric;
use crate::vertical::profile::{ProfileRestorer, VerticalProfile};

/// 2.5D 泥沙输运求解器
pub struct Transport2_5D<B: Backend> {
    /// 剖面恢复器
    profile_restorer: ProfileRestorer<B>,
    /// 垂向剖面缓存
    profile: VerticalProfile<B>,
    /// 泥沙浓度 [n_cells * n_layers]
    concentration: B::Buffer<B::Scalar>,
    /// 沉降速度
    settling_velocity: B::Scalar,
    /// 扩散系数
    diffusion_coeff: B::Scalar,
}

impl<B: Backend> Transport2_5D<B> {
    /// 创建求解器
    pub fn new(
        n_cells: usize,
        n_layers: usize,
        settling_velocity: f64,
        diffusion_coeff: f64,
    ) -> Self {
        use crate::vertical::profile::ProfileMethod;
        
        Self {
            profile_restorer: ProfileRestorer::new(n_cells, n_layers, ProfileMethod::Logarithmic),
            profile: VerticalProfile::new(n_cells, n_layers),
            concentration: B::alloc(n_cells * n_layers),
            settling_velocity: B::Scalar::from_f64(settling_velocity),
            diffusion_coeff: B::Scalar::from_f64(diffusion_coeff),
        }
    }
    
    /// 执行一步输运计算
    pub fn step(
        &mut self,
        state: &ShallowWaterStateGeneric<B>,
        dt: B::Scalar,
    ) {
        // 1. 恢复垂向剖面
        self.profile_restorer.restore(state, &mut self.profile);
        
        // 2. 计算垂向扩散和沉降
        self.compute_vertical_transport(state, dt);
        
        // 3. 计算水平对流（使用恢复的速度）
        self.compute_horizontal_advection(state, dt);
    }
    
    /// 垂向输运（扩散+沉降）
    fn compute_vertical_transport(
        &mut self,
        state: &ShallowWaterStateGeneric<B>,
        dt: B::Scalar,
    ) {
        // 简化实现：显式欧拉
        let n_cells = state.n_cells();
        let n_layers = self.profile.n_layers;
        
        let conc = self.concentration.as_slice_mut().expect("CPU buffer");
        let z_layers = self.profile.z_layers.as_slice().expect("CPU buffer");
        
        for cell in 0..n_cells {
            for k in 1..n_layers-1 {
                let idx = cell * n_layers + k;
                let idx_up = idx + 1;
                let idx_down = idx - 1;
                
                let dz_up = z_layers[idx_up] - z_layers[idx];
                let dz_down = z_layers[idx] - z_layers[idx_down];
                let dz = B::Scalar::from_f64(0.5) * (dz_up + dz_down);
                
                if dz > B::Scalar::from_f64(1e-10) {
                    // 扩散项
                    let diff = self.diffusion_coeff * (
                        (conc[idx_up] - conc[idx]) / dz_up -
                        (conc[idx] - conc[idx_down]) / dz_down
                    ) / dz;
                    
                    // 沉降项
                    let settling = -self.settling_velocity * 
                        (conc[idx] - conc[idx_down]) / dz_down;
                    
                    conc[idx] = conc[idx] + dt * (diff + settling);
                }
            }
        }
    }
    
    /// 水平对流
    fn compute_horizontal_advection(
        &mut self,
        _state: &ShallowWaterStateGeneric<B>,
        _dt: B::Scalar,
    ) {
        // TODO: 实现水平对流
        // 使用 profile.u_layers 和 profile.v_layers
    }
    
    /// 获取深度平均浓度
    pub fn depth_averaged_concentration(&self, cell: usize) -> B::Scalar {
        let n_layers = self.profile.n_layers;
        let conc = self.concentration.as_slice().expect("CPU buffer");
        
        let mut sum = B::Scalar::from_f64(0.0);
        for k in 0..n_layers {
            sum = sum + conc[cell * n_layers + k];
        }
        sum / B::Scalar::from_f64(n_layers as f64)
    }
}
```

---

## 任务 4.3: 重命名 morphology.rs

**改动文件**:
- `mh_physics/src/sediment/morphology.rs` → `mh_physics/src/sediment/morphology_2d.rs`
- `mh_physics/src/sediment/mod.rs`

```rust
// sediment/mod.rs
pub mod morphology_2d;
pub mod transport_2_5d;

pub use morphology_2d::*;
pub use transport_2_5d::Transport2_5D;
```

---

## 任务 4.4: 更新 vertical/mod.rs

**改动文件**: `mh_physics/src/vertical/mod.rs`

```rust
pub mod profile;
pub mod sigma;
pub mod state;
pub mod mixing;
pub mod velocity;

pub use profile::{ProfileRestorer, VerticalProfile, ProfileMethod};
pub use sigma::SigmaCoordinate;
```

---

# Phase 5: GPU准备

## 任务 5.1: 创建 GPU Backend 骨架

**新建文件**: `mh_physics/src/core/gpu.rs`

```rust
//! GPU 后端（骨架实现）
//!
//! 预留 CUDA 后端支持，当前仅提供接口定义。

#[cfg(feature = "cuda")]
use cudarc::driver::{CudaDevice, CudaSlice, CudaStream};

use super::backend::Backend;
use super::buffer::DeviceBuffer;
use super::scalar::Scalar;
use bytemuck::Pod;
use std::marker::PhantomData;
use std::sync::Arc;

/// CUDA 后端（feature-gated）
#[cfg(feature = "cuda")]
pub struct CudaBackend<S: Scalar> {
    device: Arc<CudaDevice>,
    stream: CudaStream,
    _marker: PhantomData<S>,
}

#[cfg(feature = "cuda")]
impl<S: Scalar> CudaBackend<S> {
    /// 创建 CUDA 后端
    pub fn new(device_id: usize) -> Result<Self, CudaError> {
        let device = CudaDevice::new(device_id)?;
        let stream = device.fork_default_stream()?;
        Ok(Self {
            device: Arc::new(device),
            stream,
            _marker: PhantomData,
        })
    }
}

#[cfg(feature = "cuda")]
impl Backend for CudaBackend<f32> {
    type Scalar = f32;
    type Buffer<T: Pod> = CudaSlice<T>;
    
    fn name() -> &'static str { "CUDA-f32" }
    
    fn alloc<T: Pod + Clone + Default>(len: usize) -> Self::Buffer<T> {
        todo!("Phase 6: CUDA implementation")
    }
    
    fn alloc_init<T: Pod + Clone>(len: usize, init: T) -> Self::Buffer<T> {
        todo!("Phase 6: CUDA implementation")
    }
    
    fn synchronize() {
        todo!("Phase 6: CUDA implementation")
    }
    
    fn axpy(alpha: f32, x: &Self::Buffer<f32>, y: &mut Self::Buffer<f32>) {
        todo!("Phase 6: CUDA implementation - use CUBLAS")
    }
    
    fn dot(x: &Self::Buffer<f32>, y: &Self::Buffer<f32>) -> f32 {
        todo!("Phase 6: CUDA implementation - use CUBLAS")
    }
    
    fn copy(src: &Self::Buffer<f32>, dst: &mut Self::Buffer<f32>) {
        todo!("Phase 6: CUDA implementation")
    }
    
    fn reduce_max(x: &Self::Buffer<f32>) -> f32 {
        todo!("Phase 6: CUDA implementation - custom kernel")
    }
    
    fn reduce_sum(x: &Self::Buffer<f32>) -> f32 {
        todo!("Phase 6: CUDA implementation - use CUBLAS")
    }
    
    fn scale(alpha: f32, x: &mut Self::Buffer<f32>) {
        todo!("Phase 6: CUDA implementation - use CUBLAS")
    }
}

/// CUDA 错误类型
#[cfg(feature = "cuda")]
#[derive(Debug)]
pub struct CudaError(String);

#[cfg(feature = "cuda")]
impl std::fmt::Display for CudaError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "CUDA error: {}", self.0)
    }
}

#[cfg(feature = "cuda")]
impl std::error::Error for CudaError {}
```

---

## 任务 5.2: 定义 Kernel 接口规范

**新建文件**: `mh_physics/src/core/kernel.rs`

```rust
//! Kernel 接口规范
//!
//! 定义 GPU kernel 的 Rust 侧接口。

use crate::core::{Backend, Scalar};

/// Kernel 优先级
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum KernelPriority {
    /// P0: 核心计算（通量、状态更新）
    Critical,
    /// P1: 重要计算（源项、梯度）
    High,
    /// P2: 辅助计算（SpMV、剖面恢复）
    Medium,
    /// P3: 可选计算
    Low,
}

/// Kernel 规范
pub struct KernelSpec {
    /// Kernel 名称
    pub name: &'static str,
    /// 优先级
    pub priority: KernelPriority,
    /// 预计加速比
    pub expected_speedup: f64,
    /// 是否已实现
    pub implemented: bool,
}

/// 核心 Kernel 列表
pub const CORE_KERNELS: &[KernelSpec] = &[
    KernelSpec {
        name: "flux_compute",
        priority: KernelPriority::Critical,
        expected_speedup: 30.0,
        implemented: false,
    },
    KernelSpec {
        name: "state_update",
        priority: KernelPriority::Critical,
        expected_speedup: 30.0,
        implemented: false,
    },
    KernelSpec {
        name: "source_batch",
        priority: KernelPriority::High,
        expected_speedup: 10.0,
        implemented: false,
    },
    KernelSpec {
        name: "gradient_compute",
        priority: KernelPriority::High,
        expected_speedup: 20.0,
        implemented: false,
    },
    KernelSpec {
        name: "spmv",
        priority: KernelPriority::Medium,
        expected_speedup: 5.0,
        implemented: false,
    },
    KernelSpec {
        name: "profile_restore",
        priority: KernelPriority::Medium,
        expected_speedup: 10.0,
        implemented: false,
    },
];

/// 传输策略
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum TransferPolicy {
    /// 延迟传输
    Lazy,
    /// 即时传输
    Eager,
    /// 流水线传输
    Pipelined,
}
```

---

## 任务 5.3: 更新 Cargo.toml

**改动文件**: `mh_physics/Cargo.toml`

```toml
[features]
default = []
cuda = ["cudarc"]

[dependencies]
# 现有依赖...

# GPU 支持（可选）
cudarc = { version = "0.10", optional = true }
```

---

## 任务 5.4: 创建性能基准测试

**新建文件**: `mh_physics/benches/solver_benchmark.rs`

```rust
//! 求解器性能基准测试

use criterion::{criterion_group, criterion_main, Criterion, BenchmarkId};
use mh_physics::core::{Backend, CpuBackend};
use mh_physics::engine::strategy::{ExplicitStrategy, ExplicitConfig};
use mh_physics::state::ShallowWaterStateGeneric;

fn benchmark_explicit_step(c: &mut Criterion) {
    let mut group = c.benchmark_group("explicit_step");
    
    for n_cells in [1000, 10000, 100000].iter() {
        group.bench_with_input(
            BenchmarkId::new("cpu_f64", n_cells),
            n_cells,
            |b, &n| {
                // 设置测试环境
                let state: ShallowWaterStateGeneric<CpuBackend<f64>> = 
                    ShallowWaterStateGeneric::new(n);
                // ... 初始化
                
                b.iter(|| {
                    // 执行单步
                });
            },
        );
    }
    
    group.finish();
}

criterion_group!(benches, benchmark_explicit_step);
criterion_main!(benches);
```

---

## 任务 5.5: 更新 core/mod.rs

**改动文件**: `mh_physics/src/core/mod.rs`

```rust
pub mod scalar;
pub mod buffer;
pub mod backend;
pub mod dimension;
pub mod kernel;

#[cfg(feature = "cuda")]
pub mod gpu;

pub use scalar::Scalar;
pub use buffer::DeviceBuffer;
pub use backend::{Backend, CpuBackend, DefaultBackend};
pub use dimension::{Dimension, D2, D3};
pub use kernel::{KernelSpec, KernelPriority, TransferPolicy, CORE_KERNELS};

#[cfg(feature = "cuda")]
pub use gpu::CudaBackend;
```

---

## 验证清单

### Phase 4 验证
- [ ] ProfileRestorer 单元测试通过
- [ ] 对数律剖面恢复正确
- [ ] Transport2_5D 可实例化
- [ ] sediment 模块编译通过

### Phase 5 验证
- [ ] `cargo check -p mh_physics` 通过
- [ ] `cargo check -p mh_physics --features cuda` 通过（如有 CUDA）
- [ ] 基准测试可运行
- [ ] Kernel 规范文档完整

```bash
cd marihydro
cargo check -p mh_physics
cargo test -p mh_physics vertical::
cargo test -p mh_physics sediment::
cargo bench -p mh_physics -- --test
```

---

## 时间估计

| 任务 | 预计时间 |
|------|----------|
| 任务 4.1 | 6 小时 |
| 任务 4.2 | 6 小时 |
| 任务 4.3-4.4 | 2 小时 |
| 任务 5.1 | 3 小时 |
| 任务 5.2 | 2 小时 |
| 任务 5.3-5.5 | 2 小时 |
| 测试与验证 | 4 小时 |
| **总计** | **~25 小时** |

---

## GPU 阶段规划（Phase 6+，仅规划）

### Kernel 优先级

| 优先级 | Kernel | 说明 | 预计加速比 |
|--------|--------|------|-----------|
| P0 | flux_compute | 通量计算 | 10-50x |
| P0 | state_update | 状态更新 | 10-50x |
| P1 | source_batch | 批量源项 | 5-20x |
| P1 | gradient_compute | 梯度计算 | 10-30x |
| P2 | spmv | 稀疏矩阵向量积 | 3-10x |
| P2 | profile_restore | 剖面恢复 | 5-15x |

### 混合调度设计

```
显式求解（纯GPU路径）:
State → [GPU] Flux → [GPU] Update → 循环

半隐式求解（混合路径）:
State → [GPU] Predict → [CPU/GPU] PCG → [GPU] Correct
```
