# MariHydro 系统架构重构计划

## 概述

本重构计划旨在解决 MariHydro 物理求解器的核心架构问题，实现：
- 求解器统一化（显式/半隐式策略模式）
- 精度泛型化（f32/f64 编译期选择）
- 硬件抽象化（CPU/GPU Backend）
- 2.5D 垂向扩展

## 阶段划分

| 阶段 | 时间 | 目标 | 文档 |
|------|------|------|------|
| Phase 0-1 | 第1-3周 | 清理死代码 + 核心抽象层 | [phase0-1_cleanup_and_core_abstraction.md](./phase0-1_cleanup_and_core_abstraction.md) |
| Phase 2 | 第4-5周 | 网格与状态泛型化 | [phase2_mesh_and_state_generics.md](./phase2_mesh_and_state_generics.md) |
| Phase 3 | 第6-8周 | 求解器策略化 | [phase3_solver_strategy.md](./phase3_solver_strategy.md) |
| Phase 4-5 | 第9-12周 | 2.5D扩展 + GPU准备 | [phase4-5_vertical_and_gpu.md](./phase4-5_vertical_and_gpu.md) |

## 核心改动

### 新建文件 (~3,100行)

```
mh_physics/src/
├── core/                    # 核心抽象层
│   ├── mod.rs
│   ├── scalar.rs           # Scalar trait
│   ├── buffer.rs           # DeviceBuffer trait
│   ├── backend.rs          # Backend trait + CpuBackend
│   ├── dimension.rs        # D2/D3 marker
│   ├── kernel.rs           # Kernel 规范
│   └── gpu.rs              # CudaBackend (feature-gated)
│
├── mesh/                    # 网格抽象层
│   ├── mod.rs
│   ├── topology.rs         # MeshTopology trait
│   ├── unstructured.rs     # FrozenMesh 适配器
│   └── structured.rs       # StructuredMesh 骨架
│
├── engine/
│   ├── workspace.rs        # SolverWorkspaceGeneric
│   └── strategy/           # 时间积分策略
│       ├── mod.rs
│       ├── explicit.rs
│       └── semi_implicit.rs
│
├── sources/
│   └── registry.rs         # SourceRegistry
│
├── vertical/
│   └── profile.rs          # ProfileRestorer
│
└── sediment/
    └── transport_2_5d.rs   # 2.5D 泥沙输运
```

### 删除文件

- `mh_physics/src/sources/turbulence/k_epsilon.rs` (3D 死代码)
- `mh_physics/src/engine/semi_implicit.rs` (迁移到 strategy/)

## 依赖关系

```
Phase 0 (清理)
    │
    ▼
Phase 1 (Backend/Buffer/Scalar)
    │
    ▼
Phase 2 (MeshTopology + State泛型化)
    │
    ▼
Phase 3 (TimeIntegrationStrategy + Solver重构)
    │
    ├──────────────────┐
    ▼                  ▼
Phase 4 (2.5D)    Phase 5 (GPU准备)
```

## 验证策略

每个阶段完成后执行：

```bash
cd marihydro
cargo check -p mh_physics
cargo test -p mh_physics
cargo test -p mh_physics -- dambreak
cargo test -p mh_physics -- thacker
```

## 时间估计

| 阶段 | 预计时间 |
|------|----------|
| Phase 0-1 | ~13 小时 |
| Phase 2 | ~18 小时 |
| Phase 3 | ~32 小时 |
| Phase 4-5 | ~25 小时 |
| **总计** | **~88 小时** |

## 风险与缓解

| 风险 | 缓解措施 |
|------|----------|
| 泛型爆炸导致编译时间增加 | 使用类型别名减少泛型传播 |
| f32 精度不足 | 关键路径强制 f64 |
| 半隐式 PCG 不收敛 | 预条件器 + 自动回退显式 |
| GPU 内存溢出 | 分块处理 + 动态内存池 |
