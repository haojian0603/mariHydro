// src-tauri/src/marihydro/physics/sources/diffusion.rs
// Generated: 2025-11-30
// Issue: H006, PERF-001
// Performance: 使用传入缓冲区消除临时分配，预计减少内存分配80%

use rayon::prelude::*;
use crate::marihydro::core::error::{MhError, MhResult};
use crate::marihydro::core::traits::mesh::MeshAccess;

pub fn apply_diffusion_explicit<M: MeshAccess>(
    field: &[f64], field_out: &mut [f64], mesh: &M, nu: f64, dt: f64, flux_buffer: &mut [f64],
) -> MhResult<()> {
    validate_diffusion_params(nu, dt)?;
    let n = mesh.n_cells();
    if field.len() != n || field_out.len() != n || flux_buffer.len() != n {
        return Err(MhError::InvalidInput(format!(
            "Array size mismatch: n={}, field={}, out={}, buf={}",
            n, field.len(), field_out.len(), flux_buffer.len()
        )));
    }
    compute_diffusion_fluxes_into(field, mesh, nu, flux_buffer);
    field_out.par_iter_mut().enumerate().for_each(|(i, out)| {
        let area = mesh.cell_area(i);
        *out = if area > 1e-14 { field[i] + dt * flux_buffer[i] / area } else { field[i] };
    });
    Ok(())
}

fn compute_diffusion_fluxes_into<M: MeshAccess>(field: &[f64], mesh: &M, nu: f64, flux_sum: &mut [f64]) {
    flux_sum.fill(0.0);
    for face_idx in 0..mesh.n_faces() {
        if mesh.is_boundary_face(face_idx) { continue; }
        let (owner, neighbor) = mesh.face_cells(face_idx);
        if neighbor.is_none() { continue; }
        let neighbor = neighbor.unwrap();
        let d = mesh.face_distance(face_idx);
        if d < 1e-14 { continue; }
        let length = mesh.face_length(face_idx);
        let flux = -nu * (field[neighbor] - field[owner]) / d * length;
        flux_sum[owner] += flux;
        flux_sum[neighbor] -= flux;
    }
}

pub fn apply_diffusion_explicit_variable<M: MeshAccess>(
    field: &[f64], field_out: &mut [f64], mesh: &M, nu: &[f64], dt: f64, flux_buffer: &mut [f64],
) -> MhResult<()> {
    let n = mesh.n_cells();
    if field.len() != n || field_out.len() != n || nu.len() != n || flux_buffer.len() != n {
        return Err(MhError::InvalidInput("Array size mismatch".into()));
    }
    flux_buffer.fill(0.0);
    for face_idx in 0..mesh.n_faces() {
        if mesh.is_boundary_face(face_idx) { continue; }
        let (owner, neighbor_opt) = mesh.face_cells(face_idx);
        if neighbor_opt.is_none() { continue; }
        let neighbor = neighbor_opt.unwrap();
        let d = mesh.face_distance(face_idx);
        if d < 1e-14 { continue; }
        let length = mesh.face_length(face_idx);
        let nu_o = nu[owner];
        let nu_n = nu[neighbor];
        let nu_face = if nu_o + nu_n > 1e-14 { 2.0 * nu_o * nu_n / (nu_o + nu_n) } else { 0.0 };
        let flux = -nu_face * (field[neighbor] - field[owner]) / d * length;
        flux_buffer[owner] += flux;
        flux_buffer[neighbor] -= flux;
    }
    field_out.par_iter_mut().enumerate().for_each(|(i, out)| {
        let area = mesh.cell_area(i);
        *out = if area > 1e-14 { field[i] + dt * flux_buffer[i] / area } else { field[i] };
    });
    Ok(())
}

pub fn apply_diffusion_inplace<M: MeshAccess>(
    field: &mut [f64], mesh: &M, nu: f64, dt: f64, temp_buffer: &mut [f64], flux_buffer: &mut [f64],
) -> MhResult<()> {
    apply_diffusion_explicit(field, temp_buffer, mesh, nu, dt, flux_buffer)?;
    field.copy_from_slice(temp_buffer);
    Ok(())
}

pub fn apply_diffusion_substeps<M: MeshAccess>(
    field: &mut [f64], mesh: &M, nu: f64, dt: f64, n_substeps: usize,
    buffer_a: &mut [f64], buffer_b: &mut [f64], flux_buffer: &mut [f64],
) -> MhResult<()> {
    if n_substeps == 0 { return Ok(()); }
    let sub_dt = dt / n_substeps as f64;
    buffer_a.copy_from_slice(field);
    for step in 0..n_substeps {
        if step % 2 == 0 {
            apply_diffusion_explicit(buffer_a, buffer_b, mesh, nu, sub_dt, flux_buffer)?;
        } else {
            apply_diffusion_explicit(buffer_b, buffer_a, mesh, nu, sub_dt, flux_buffer)?;
        }
    }
    if n_substeps % 2 == 1 {
        field.copy_from_slice(buffer_b);
    } else {
        field.copy_from_slice(buffer_a);
    }
    Ok(())
}

fn validate_diffusion_params(nu: f64, dt: f64) -> MhResult<()> {
    if nu < 0.0 {
        return Err(MhError::InvalidInput(format!("Diffusion ν cannot be negative: {:.3}", nu)));
    }
    if dt <= 0.0 {
        return Err(MhError::InvalidInput(format!("Time step must be positive: dt={:.3}", dt)));
    }
    Ok(())
}

pub struct DiffusionWorkspace {
    pub flux_buffer: Vec<f64>,
    pub temp_a: Vec<f64>,
    pub temp_b: Vec<f64>,
}

impl DiffusionWorkspace {
    pub fn new(n_cells: usize) -> Self {
        Self {
            flux_buffer: vec![0.0; n_cells],
            temp_a: vec![0.0; n_cells],
            temp_b: vec![0.0; n_cells],
        }
    }

    pub fn resize(&mut self, n_cells: usize) {
        self.flux_buffer.resize(n_cells, 0.0);
        self.temp_a.resize(n_cells, 0.0);
        self.temp_b.resize(n_cells, 0.0);
    }
}
