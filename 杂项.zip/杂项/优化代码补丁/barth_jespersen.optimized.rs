// src-tauri/src/marihydro/physics/numerics/limiter/barth_jespersen.rs
// Generated: 2025-11-30
// Issue: H007, PERF-002
// Performance: 并行化梯度限制器，预计加速4-8x

use crate::marihydro::core::traits::mesh::MeshAccess;
use crate::marihydro::core::traits::limiter::GradientLimiter;
use crate::marihydro::core::types::CellIndex;
use crate::marihydro::physics::numerics::gradient::ScalarGradientStorage;
use glam::DVec2;
use rayon::prelude::*;

pub struct BarthJespersenLimiter {
    parallel_threshold: usize,
}

impl Default for BarthJespersenLimiter {
    fn default() -> Self { Self { parallel_threshold: 1000 } }
}

impl BarthJespersenLimiter {
    pub fn new() -> Self { Self::default() }
    pub fn with_threshold(mut self, t: usize) -> Self { self.parallel_threshold = t; self }

    fn compute_alpha<M: MeshAccess>(&self, cell_idx: usize, field: &[f64], grad: &ScalarGradientStorage, mesh: &M) -> f64 {
        let phi_c = field[cell_idx];
        let g = grad.get(cell_idx);
        let center = mesh.cell_centroid(CellIndex(cell_idx));
        let mut phi_min = phi_c;
        let mut phi_max = phi_c;
        for &face in mesh.cell_faces(CellIndex(cell_idx)) {
            let neighbor = mesh.face_neighbor(face);
            if neighbor.is_valid() {
                let phi_n = field[neighbor.0];
                phi_min = phi_min.min(phi_n);
                phi_max = phi_max.max(phi_n);
            }
        }
        let mut alpha = 1.0;
        for &face in mesh.cell_faces(CellIndex(cell_idx)) {
            let fc = mesh.face_centroid(face);
            let d = fc - center;
            let phi_face = phi_c + g.dot(d);
            let delta = phi_face - phi_c;
            if delta.abs() > 1e-14 {
                let r = if delta > 0.0 { (phi_max - phi_c) / delta } else { (phi_min - phi_c) / delta };
                alpha = alpha.min(r.clamp(0.0, 1.0));
            }
        }
        alpha
    }
}

impl GradientLimiter for BarthJespersenLimiter {
    fn limit<M: MeshAccess + Sync>(&self, field: &[f64], grad: &mut ScalarGradientStorage, mesh: &M) {
        let n = mesh.n_cells();
        if n >= self.parallel_threshold {
            let alphas: Vec<f64> = (0..n).into_par_iter()
                .map(|i| self.compute_alpha(i, field, grad, mesh))
                .collect();
            for i in 0..n {
                let g = grad.get(i);
                grad.set(i, g * alphas[i]);
            }
        } else {
            for i in 0..n {
                let alpha = self.compute_alpha(i, field, grad, mesh);
                let g = grad.get(i);
                grad.set(i, g * alpha);
            }
        }
    }

    fn name(&self) -> &'static str { "Barth-Jespersen-Parallel" }
}

pub struct VenkatakrishnanLimiter {
    k: f64,
    parallel_threshold: usize,
}

impl VenkatakrishnanLimiter {
    pub fn new(k: f64) -> Self { Self { k, parallel_threshold: 1000 } }
    pub fn with_threshold(mut self, t: usize) -> Self { self.parallel_threshold = t; self }

    fn compute_alpha<M: MeshAccess>(&self, cell_idx: usize, field: &[f64], grad: &ScalarGradientStorage, mesh: &M) -> f64 {
        let phi_c = field[cell_idx];
        let g = grad.get(cell_idx);
        let center = mesh.cell_centroid(CellIndex(cell_idx));
        let area = mesh.cell_area(CellIndex(cell_idx));
        let dx = area.sqrt();
        let eps2 = (self.k * dx).powi(3);
        let mut phi_min = phi_c;
        let mut phi_max = phi_c;
        for &face in mesh.cell_faces(CellIndex(cell_idx)) {
            let neighbor = mesh.face_neighbor(face);
            if neighbor.is_valid() {
                let phi_n = field[neighbor.0];
                phi_min = phi_min.min(phi_n);
                phi_max = phi_max.max(phi_n);
            }
        }
        let delta_max = phi_max - phi_c;
        let delta_min = phi_min - phi_c;
        let mut alpha = 1.0;
        for &face in mesh.cell_faces(CellIndex(cell_idx)) {
            let fc = mesh.face_centroid(face);
            let d = fc - center;
            let phi_face = phi_c + g.dot(d);
            let delta = phi_face - phi_c;
            if delta.abs() < 1e-14 { continue; }
            let dm = if delta > 0.0 { delta_max } else { delta_min };
            let dm2 = dm * dm;
            let d2 = delta * delta;
            let phi = (dm2 + eps2 + 2.0 * delta * dm) / (dm2 + 2.0 * d2 + dm * delta + eps2);
            alpha = alpha.min(phi.clamp(0.0, 1.0));
        }
        alpha
    }
}

impl GradientLimiter for VenkatakrishnanLimiter {
    fn limit<M: MeshAccess + Sync>(&self, field: &[f64], grad: &mut ScalarGradientStorage, mesh: &M) {
        let n = mesh.n_cells();
        if n >= self.parallel_threshold {
            let alphas: Vec<f64> = (0..n).into_par_iter()
                .map(|i| self.compute_alpha(i, field, grad, mesh))
                .collect();
            for i in 0..n { let g = grad.get(i); grad.set(i, g * alphas[i]); }
        } else {
            for i in 0..n {
                let alpha = self.compute_alpha(i, field, grad, mesh);
                let g = grad.get(i); grad.set(i, g * alpha);
            }
        }
    }

    fn name(&self) -> &'static str { "Venkatakrishnan-Parallel" }
}
