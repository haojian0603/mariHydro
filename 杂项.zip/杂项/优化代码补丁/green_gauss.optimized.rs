// src-tauri/src/marihydro/physics/numerics/gradient/green_gauss.rs
// Generated: 2025-11-30
// Issue: H002, H009, PERF-002, PERF-004
// Performance: 并行化Green-Gauss梯度，基于单元循环消除数据竞争，预计加速4-8x

use super::traits::{GradientMethod, ScalarGradientStorage, VectorGradientStorage};
use crate::marihydro::core::error::MhResult;
use crate::marihydro::core::traits::mesh::MeshAccess;
use crate::marihydro::core::types::{CellIndex, FaceIndex};
use glam::DVec2;
use rayon::prelude::*;

pub struct GreenGaussGradient {
    parallel_threshold: usize,
}

impl Default for GreenGaussGradient {
    fn default() -> Self { Self { parallel_threshold: 1000 } }
}

impl GreenGaussGradient {
    pub fn new() -> Self { Self::default() }
    pub fn with_threshold(mut self, t: usize) -> Self { self.parallel_threshold = t; self }

    #[inline(always)]
    fn compute_cell_scalar<M: MeshAccess>(&self, cell_idx: usize, field: &[f64], mesh: &M) -> DVec2 {
        let cell = CellIndex(cell_idx);
        let area = mesh.cell_area(cell);
        if area < 1e-14 { return DVec2::ZERO; }
        let mut grad = DVec2::ZERO;
        for &face in mesh.cell_faces(cell) {
            let owner = mesh.face_owner(face);
            let neighbor = mesh.face_neighbor(face);
            let normal = mesh.face_normal(face);
            let length = mesh.face_length(face);
            let sign = if cell_idx == owner.0 { 1.0 } else { -1.0 };
            let ds = normal * length * sign;
            let phi_face = if !neighbor.is_valid() { field[cell_idx] }
            else { 0.5 * (field[cell_idx] + field[if cell_idx == owner.0 { neighbor.0 } else { owner.0 }]) };
            grad += ds * phi_face;
        }
        grad / area
    }

    #[inline(always)]
    fn compute_cell_vector<M: MeshAccess>(&self, cell_idx: usize, field: &[DVec2], mesh: &M) -> (DVec2, DVec2) {
        let cell = CellIndex(cell_idx);
        let area = mesh.cell_area(cell);
        if area < 1e-14 { return (DVec2::ZERO, DVec2::ZERO); }
        let mut grad_u = DVec2::ZERO;
        let mut grad_v = DVec2::ZERO;
        for &face in mesh.cell_faces(cell) {
            let owner = mesh.face_owner(face);
            let neighbor = mesh.face_neighbor(face);
            let normal = mesh.face_normal(face);
            let length = mesh.face_length(face);
            let sign = if cell_idx == owner.0 { 1.0 } else { -1.0 };
            let ds = normal * length * sign;
            let vel = if !neighbor.is_valid() { field[cell_idx] }
            else { (field[cell_idx] + field[if cell_idx == owner.0 { neighbor.0 } else { owner.0 }]) * 0.5 };
            grad_u += ds * vel.x;
            grad_v += ds * vel.y;
        }
        (grad_u / area, grad_v / area)
    }
}

impl GradientMethod for GreenGaussGradient {
    fn compute_scalar_gradient<M: MeshAccess + Sync>(
        &self, field: &[f64], mesh: &M, output: &mut ScalarGradientStorage,
    ) -> MhResult<()> {
        output.reset();
        let n = mesh.n_cells();
        if n >= self.parallel_threshold {
            let grads: Vec<DVec2> = (0..n).into_par_iter()
                .map(|i| self.compute_cell_scalar(i, field, mesh))
                .collect();
            for (i, g) in grads.into_iter().enumerate() { output.set(i, g); }
        } else {
            for i in 0..n { output.set(i, self.compute_cell_scalar(i, field, mesh)); }
        }
        Ok(())
    }

    fn compute_vector_gradient<M: MeshAccess + Sync>(
        &self, field: &[DVec2], mesh: &M, output: &mut VectorGradientStorage,
    ) -> MhResult<()> {
        output.reset();
        let n = mesh.n_cells();
        if n >= self.parallel_threshold {
            let grads: Vec<(DVec2, DVec2)> = (0..n).into_par_iter()
                .map(|i| self.compute_cell_vector(i, field, mesh))
                .collect();
            for (i, (gu, gv)) in grads.into_iter().enumerate() {
                output.set_grad_u(i, gu);
                output.set_grad_v(i, gv);
            }
        } else {
            for i in 0..n {
                let (gu, gv) = self.compute_cell_vector(i, field, mesh);
                output.set_grad_u(i, gu);
                output.set_grad_v(i, gv);
            }
        }
        Ok(())
    }

    fn name(&self) -> &'static str { "Green-Gauss-Parallel" }
}
